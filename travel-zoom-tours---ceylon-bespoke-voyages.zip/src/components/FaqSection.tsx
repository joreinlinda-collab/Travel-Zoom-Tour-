import React, { useState } from 'react';
import { FAQ_LIST, FaqItem } from '../data/toursData';

export const FaqSection: React.FC = () => {
  const [openIds, setOpenIds] = useState<number[]>([1]); // First FAQ open by default

  const toggleFaq = (id: number) => {
    setOpenIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  return (
    <section className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#0b0f10]">
      <div className="max-w-4xl mx-auto flex flex-col gap-10">
        <div className="flex flex-col gap-2 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Answers & Clarifications
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Frequently Asked Questions
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed">
            Everything you need to know about booking private chauffeur tours with Travel Zoom Tours Sri Lanka.
          </p>
        </div>

        {/* FAQ Accordions */}
        <div className="flex flex-col gap-3">
          {FAQ_LIST.map((faq: FaqItem) => {
            const isOpen = openIds.includes(faq.id);

            return (
              <div
                key={faq.id}
                className="rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-sm transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(faq.id)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 hover:text-[#eec14b] transition-colors"
                >
                  <span className="font-serif text-lg sm:text-xl text-[#e0e3e5]">
                    {faq.question}
                  </span>
                  <span
                    className={`material-symbols-outlined text-[#eec14b] text-[22px] transform transition-transform duration-300 shrink-0 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  >
                    expand_more
                  </span>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-[#d1c5af] font-light leading-relaxed border-t border-[#272a2c]/60 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
