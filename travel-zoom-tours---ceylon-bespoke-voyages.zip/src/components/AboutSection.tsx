import React from 'react';

export const AboutSection: React.FC = () => {
  return (
    <section className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#0b0f10]">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
        <div className="lg:col-span-6 flex flex-col gap-6">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            About Travel Zoom Tours
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5] leading-tight">
            Curators of Ceylon’s Most Authentic Memories
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed">
            Headquartered in Sri Lanka, Travel Zoom Tours was founded on an unwavering commitment: to liberate international travelers from cookie-cutter bus itineraries and deliver intimate, bespoke chauffeur-led discoveries with pure Sri Lankan warmth.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            <div className="p-4 rounded-xl bg-[#191c1e] border border-[#272a2c] shadow-sm flex flex-col gap-1.5">
              <div className="flex items-center gap-2 text-[#eec14b]">
                <span className="material-symbols-outlined text-[20px]">handshake</span>
                <span className="text-xs font-bold uppercase">Honest Pricing</span>
              </div>
              <p className="text-xs text-[#d1c5af] font-light leading-relaxed">
                Zero hidden fuel surcharges, driver allowances, or toll markups. Complete line-item clarity.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-[#191c1e] border border-[#272a2c] shadow-sm flex flex-col gap-1.5">
              <div className="flex items-center gap-2 text-[#eec14b]">
                <span className="material-symbols-outlined text-[20px]">headset_mic</span>
                <span className="text-xs font-bold uppercase">24/7 Concierge</span>
              </div>
              <p className="text-xs text-[#d1c5af] font-light leading-relaxed">
                Dedicated senior travel designer monitoring your voyage real-time via WhatsApp from arrival to departure.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 relative">
          <div className="w-full h-80 sm:h-[450px] rounded-3xl overflow-hidden shadow-2xl relative border border-[#272a2c]">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAXnw_7P-jIkMSUqNjWrz9aMHMMqeBbPpyU_p1sn89WwCYkbsJJ7nju55pzXvC5rDv-r7e34yBmjYJGrHvv6GKKVn8QAY3CVnbK7OHRjAyxIh_vxn7XD3HaiN-I-eFXlOfw_AAC-fZgVeJV_FSKTvK4sPDwSFiVQZgi6bhZT94qZFXQtHHz8j7F7kOSv2asZq2rn6hA6sFCEuhlUJGZxsz4oif91xFc3m7m3HMoh_CyneY8fLuaJYlA"
              alt="Traditional Sri Lankan hospitality greeting: Private chauffeur guide welcoming guests with warm hands together and fragrant jasmine flower garlands."
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0f10] via-transparent to-transparent" />

            <div className="absolute bottom-5 left-5 right-5 p-4 sm:p-5 rounded-2xl bg-[#272a2c]/90 border border-[#eec14b]/30 backdrop-blur-md shadow-xl flex items-center justify-between gap-3">
              <div className="flex flex-col">
                <span className="font-serif text-lg sm:text-xl text-[#eec14b] font-bold">
                  100% Sri Lankan Owned
                </span>
                <span className="text-xs text-[#d1c5af] font-light">
                  Direct local operators • Supporting regional communities
                </span>
              </div>
              <span className="material-symbols-outlined text-[#eec14b] text-[34px] shrink-0">
                workspace_premium
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
