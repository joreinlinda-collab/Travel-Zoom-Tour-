import React from 'react';
import { FLEET_VEHICLES, FleetVehicle } from '../data/toursData';

export const TransportFleetSection: React.FC = () => {
  return (
    <section id="transport" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#0b0f10]">
      <div className="max-w-7xl mx-auto flex flex-col gap-12 sm:gap-14">
        {/* Section Title */}
        <div className="flex flex-col gap-2 max-w-3xl">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Private Fleet & Certified Escorts
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Luxury Transport & Expert Tour Chauffeur Guides
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed">
            Every journey is accompanied by our certified, multi-lingual Sri Lankan tour chauffeur guides in spotless, modern air-conditioned private vehicles. Unlimited passenger insurance, highway tolls, and driver board & lodging are always included.
          </p>
        </div>

        {/* 4 Fleet Vehicles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {FLEET_VEHICLES.map((vehicle: FleetVehicle) => (
            <div
              key={vehicle.id}
              className="rounded-2xl bg-[#191c1e] border border-[#272a2c] p-5 flex flex-col justify-between gap-5 shadow-lg group hover:border-[#eec14b]/30 transition-all"
            >
              <div className="flex flex-col gap-3">
                <div className="w-full h-44 rounded-xl overflow-hidden relative">
                  <img
                    src={vehicle.image}
                    alt={vehicle.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <span className="absolute top-2.5 left-2.5 px-2.5 py-1 rounded bg-[#101415]/90 backdrop-blur-md text-[#eec14b] text-[10px] font-bold uppercase tracking-wider">
                    {vehicle.capacity}
                  </span>
                </div>

                <h3 className="font-serif text-xl text-[#e0e3e5]">{vehicle.title}</h3>
                <p className="text-xs text-[#d1c5af] font-light leading-relaxed">
                  {vehicle.description}
                </p>

                <div className="flex flex-col gap-1.5 text-xs text-[#d1c5af] pt-1 border-t border-[#272a2c]">
                  {vehicle.features.map((feat, i) => (
                    <span key={i} className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-[15px] text-[#80d9a1] shrink-0">
                        {i === 0 ? 'ac_unit' : i === 1 ? 'luggage' : 'wifi'}
                      </span>
                      <span>{feat}</span>
                    </span>
                  ))}
                </div>
              </div>

              <a
                href={`https://wa.me/94702216999?text=${encodeURIComponent(
                  `Hello Travel Zoom Tours, I am inquiring about the ${vehicle.title} (${vehicle.capacity}) with private chauffeur guide.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 px-3 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#eec14b] text-xs font-bold uppercase tracking-wider text-center transition-colors border border-[#4e4635]/40 flex items-center justify-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[16px]">chat</span>
                <span>Inquire Fleet Rate</span>
              </a>
            </div>
          ))}
        </div>

        {/* Professional Tour Guide Standards & Credentials */}
        <div className="p-6 sm:p-8 rounded-2xl bg-[#191c1e] border border-[#272a2c] shadow-xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#eec14b]">
                SLTDA Vetted
              </span>
              <h3 className="font-serif text-2xl text-[#e0e3e5]">Certified Chauffeur Guides</h3>
              <p className="text-xs sm:text-sm text-[#d1c5af] font-light leading-relaxed">
                Every Travel Zoom driver is an accredited National Tour Guide Lecturer or Certified Chauffeur Guide licensed by the Sri Lanka Tourism Development Authority (SLTDA).
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#eec14b] text-[22px] mt-0.5 shrink-0">
                  translate
                </span>
                <div>
                  <h4 className="text-xs font-bold text-[#e0e3e5] uppercase tracking-wider">
                    Multi-Lingual Fluency
                  </h4>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed mt-0.5">
                    Fluent English chauffeurs standard. Fluent German, French, and Japanese tour guides available on request.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#eec14b] text-[22px] mt-0.5 shrink-0">
                  history_edu
                </span>
                <div>
                  <h4 className="text-xs font-bold text-[#e0e3e5] uppercase tracking-wider">
                    Cultural & Archaeology Specialists
                  </h4>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed mt-0.5">
                    Deep historical expertise across Anuradhapura, Polonnaruwa, Sigiriya, and the sacred Temple of the Tooth.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#eec14b] text-[22px] mt-0.5 shrink-0">
                  nature
                </span>
                <div>
                  <h4 className="text-xs font-bold text-[#e0e3e5] uppercase tracking-wider">
                    Wildlife Naturalists
                  </h4>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed mt-0.5">
                    Trained animal trackers in Yala, Wilpattu, and Minneriya who adhere strictly to wildlife ethics and zero-harassment rules.
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <span className="material-symbols-outlined text-[#eec14b] text-[22px] mt-0.5 shrink-0">
                  security
                </span>
                <div>
                  <h4 className="text-xs font-bold text-[#e0e3e5] uppercase tracking-wider">
                    Zero Commission Shopping Guarantee
                  </h4>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed mt-0.5">
                    You will never be taken to forced souvenir traps. 100% authentic recommendations designed around your true wishes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
