import React, { useState } from 'react';

export interface BookingFormData {
  fullName: string;
  email: string;
  phone: string;
  country: string;
  arrivalDate: string;
  travelers: string;
  selectedPackage: string;
  accommodation: string;
  notes: string;
}

interface BookingSectionProps {
  initialPackage?: string;
  initialDate?: string;
  initialTravelers?: string;
  initialStyle?: string;
  onSubmitBooking: (data: BookingFormData) => void;
}

export const BookingSection: React.FC<BookingSectionProps> = ({
  initialPackage = '7-Day Cultural & Hill Country (Anuradhapura 1st)',
  initialDate,
  initialTravelers = '2 Adults (Couple / Friends)',
  onSubmitBooking,
}) => {
  const getDefaultDate = () => {
    if (initialDate) return initialDate;
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  };

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('');
  const [arrivalDate, setArrivalDate] = useState(getDefaultDate());
  const [travelers, setTravelers] = useState(initialTravelers);
  const [selectedPackage, setSelectedPackage] = useState(initialPackage);
  const [accommodation, setAccommodation] = useState('5-Star Luxury & Heritage Bungalows');
  const [notes, setNotes] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmitBooking({
      fullName,
      email,
      phone,
      country,
      arrivalDate,
      travelers,
      selectedPackage,
      accommodation,
      notes,
    });
  };

  return (
    <section id="contact" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#101415]">
      <div className="max-w-4xl mx-auto flex flex-col gap-8">
        <div className="flex flex-col gap-2 text-center">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Begin Your Journey
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Design Your Bespoke Sri Lankan Voyage
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed max-w-2xl mx-auto">
            Submit your preferences below. Our booking engine validates your requirements and instantly connects you with our local tour planner in Sri Lanka via pre-filled WhatsApp for real-time quotation.
          </p>
        </div>

        {/* Main Booking Form Card */}
        <div className="rounded-3xl bg-[#191c1e] border border-[#272a2c] p-6 sm:p-10 shadow-2xl">
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Full Name */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Full Name *
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="e.g. Eleanor Vance"
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors"
              />
            </div>

            {/* Email Address */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Email Address *
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="eleanor@example.com"
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors"
              />
            </div>

            {/* WhatsApp Number */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                WhatsApp Number with Country Code *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+44 7911 123456"
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors"
              />
            </div>

            {/* Country of Residence */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Nationality / Country *
              </label>
              <input
                type="text"
                required
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                placeholder="e.g. United Kingdom"
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors"
              />
            </div>

            {/* Arrival Date */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Estimated Arrival Date
              </label>
              <input
                type="date"
                value={arrivalDate}
                onChange={(e) => setArrivalDate(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors"
              />
            </div>

            {/* Number of Guests */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Number of Travelers
              </label>
              <select
                value={travelers}
                onChange={(e) => setTravelers(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors appearance-none"
              >
                <option value="1 Solo Traveler">1 Solo Traveler</option>
                <option value="2 Adults (Couple / Friends)">2 Adults (Couple / Friends)</option>
                <option value="3-4 Adults (Small Group)">3-4 Adults</option>
                <option value="Family with Children">Family with Children</option>
                <option value="5+ Large Group">5+ Group Delegation</option>
              </select>
            </div>

            {/* Desired Duration */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Preferred Tour Package
              </label>
              <select
                value={selectedPackage}
                onChange={(e) => setSelectedPackage(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors appearance-none"
              >
                <option value="3-Day Cultural Discovery (Anuradhapura 1st)">3-Day Cultural Discovery</option>
                <option value="5-Day Cultural Highlights (Anuradhapura 1st)">5-Day Cultural Highlights</option>
                <option value="7-Day Cultural & Hill Country (Anuradhapura 1st)">7-Day Cultural & Hill Country</option>
                <option value="10-Day Heritage, Nature & Safari (Anuradhapura 1st)">10-Day Heritage, Nature & Safari</option>
                <option value="15-Day Discovery Grand Tour (Anuradhapura 1st)">15-Day Discovery Grand Tour</option>
                <option value="20-Day Complete Island Odyssey (Anuradhapura 1st)">20-Day Complete Island Odyssey</option>
                <option value="30-Day Royal Ceylon Immersion (Anuradhapura 1st)">30-Day Royal Ceylon Immersion</option>
                <option value="Custom Bespoke Route (Starting in Anuradhapura)">Fully Tailored Custom Itinerary</option>
              </select>
            </div>

            {/* Accommodation Tier */}
            <div className="flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Accommodation Preference
              </label>
              <select
                value={accommodation}
                onChange={(e) => setAccommodation(e.target.value)}
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors appearance-none"
              >
                <option value="5-Star Luxury & Heritage Bungalows">5-Star Luxury & Heritage Bungalows</option>
                <option value="4-Star Boutique Handpicked Comfort">4-Star Boutique Comfort</option>
                <option value="3-Star Clean Quality Eco Lodges">3-Star Clean Quality Eco Lodges</option>
                <option value="Driver & Transport Only (Hotels self-booked)">Driver & Transport Only (Self-booked hotels)</option>
              </select>
            </div>

            {/* Special Requests */}
            <div className="sm:col-span-2 flex flex-col gap-1.5">
              <label className="text-[11px] font-bold uppercase tracking-wider text-[#d1c5af]">
                Special Requests / Preferences
              </label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Tell us if you have dietary restrictions, mobility preferences, specific wildlife goals, or flight times..."
                className="w-full px-4 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] shadow-inner transition-colors resize-none"
              />
            </div>

            {/* Golden Rule Notice */}
            <div className="sm:col-span-2 p-3 rounded-xl bg-[#101415] border border-[#272a2c] text-xs text-[#d1c5af] flex items-center gap-2">
              <span className="material-symbols-outlined text-[#eec14b] text-[18px] shrink-0">info</span>
              <span>All proposed routes automatically begin with prompt VIP airport pickup and transit to Anuradhapura.</span>
            </div>

            {/* Submit Button */}
            <div className="sm:col-span-2 flex flex-col gap-2 pt-2">
              <button
                type="submit"
                className="w-full py-3.5 px-6 rounded-xl bg-[#eec14b] text-[#3e2e00] text-xs font-bold uppercase tracking-wider hover:bg-[#ffdf98] transition-all shadow-xl flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-[20px]">send</span>
                <span>Generate WhatsApp Proposal & Connect</span>
              </button>
              <p className="text-[11px] text-[#9a907c] text-center font-light">
                This is a direct-to-expert inquiry. Your inquiry opens in WhatsApp (+94 70 221 6999) to connect you directly with our local tour planner in Sri Lanka.
              </p>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
