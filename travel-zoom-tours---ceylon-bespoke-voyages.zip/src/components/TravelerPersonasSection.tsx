import React from 'react';
import { TRAVELER_PERSONAS, TravelerPersona } from '../data/toursData';

interface TravelerPersonasSectionProps {
  onSelectPersona: (style: string) => void;
}

export const TravelerPersonasSection: React.FC<TravelerPersonasSectionProps> = ({ onSelectPersona }) => {
  return (
    <section className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#101415]">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
              Signature Travel Personas
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5] leading-tight">
              Curated For How You Love To Travel
            </h2>
          </div>
          <p className="text-sm text-[#d1c5af] max-w-md font-light leading-relaxed">
            Select your journey style to discover purpose-built routes, hand-picked heritage retreats, and private chauffeur paces designed for you.
          </p>
        </div>

        {/* 8 Traveler Personas Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {TRAVELER_PERSONAS.map((persona: TravelerPersona) => (
            <button
              key={persona.id}
              type="button"
              onClick={() => onSelectPersona(persona.filterStyle)}
              className="group text-left p-6 rounded-2xl bg-[#191c1e] hover:bg-[#1d2022] border border-[#272a2c] hover:border-[#eec14b]/40 transition-all flex flex-col justify-between h-64 shadow-md relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#eec14b]/5 rounded-bl-full pointer-events-none group-hover:scale-125 transition-transform" />
              
              <div className="flex items-center justify-between w-full">
                <div className="w-12 h-12 rounded-xl bg-[#272a2c] flex items-center justify-center text-[#eec14b] group-hover:bg-[#eec14b] group-hover:text-[#3e2e00] transition-colors shadow-inner">
                  <span className="material-symbols-outlined text-[26px]">{persona.icon}</span>
                </div>
                <span className="text-xs text-[#9a907c] tracking-widest font-mono font-semibold">
                  #{persona.number}
                </span>
              </div>

              <div className="flex flex-col gap-1.5">
                <h3 className="font-serif text-xl text-[#e0e3e5] group-hover:text-[#eec14b] transition-colors leading-snug">
                  {persona.title}
                </h3>
                <p className="text-xs text-[#d1c5af] line-clamp-2 leading-relaxed font-light">
                  {persona.description}
                </p>
              </div>

              <span className="text-[11px] font-bold uppercase tracking-wider text-[#eec14b] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                <span>Filter Packages</span>
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
