import React from 'react';
import { ITINERARY_DATA, DayPlan } from '../data/toursData';

interface ItineraryTimelineSectionProps {
  activeDays: number;
  onSelectDays: (days: number) => void;
  onRequestRoute: (title: string) => void;
}

export const ItineraryTimelineSection: React.FC<ItineraryTimelineSectionProps> = ({
  activeDays,
  onSelectDays,
  onRequestRoute,
}) => {
  const currentItinerary = ITINERARY_DATA[activeDays] || ITINERARY_DATA[7];

  const handlePrint = () => {
    window.print();
  };

  return (
    <section id="itineraries" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#101415]">
      <div className="max-w-7xl mx-auto flex flex-col gap-8 sm:gap-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
              Day-by-Day Transparency
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
              Explore Detailed Daily Itineraries
            </h2>
          </div>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#e0e3e5] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 border border-[#4e4635]/40 transition-colors"
            >
              <span className="material-symbols-outlined text-[16px] text-[#eec14b]">print</span>
              <span>Print / Save</span>
            </button>
            <button
              type="button"
              onClick={() => onRequestRoute(currentItinerary.title)}
              className="px-4 py-2 rounded-lg bg-[#eec14b] hover:bg-[#ffdf98] text-[#3e2e00] text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-colors"
            >
              <span className="material-symbols-outlined text-[16px]">draw</span>
              <span>Request This Route</span>
            </button>
          </div>
        </div>

        {/* Tour Day Switcher Buttons */}
        <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-x-auto no-scrollbar">
          {[3, 5, 7, 10, 15, 20, 30].map((daysCount) => (
            <button
              key={daysCount}
              type="button"
              onClick={() => onSelectDays(daysCount)}
              className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap ${
                activeDays === daysCount
                  ? 'bg-[#eec14b] text-[#3e2e00] shadow-md font-extrabold'
                  : 'text-[#d1c5af] hover:text-[#eec14b] hover:bg-[#272a2c]'
              }`}
            >
              {daysCount === 30 ? '30-Day Immersion' : `${daysCount}-Day Tour`}
            </button>
          ))}
        </div>

        {/* Active Itinerary Overview Header */}
        <div className="p-6 sm:p-7 rounded-2xl bg-[#191c1e] border border-[#272a2c] flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-lg">
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center gap-2 text-xs font-bold text-[#80d9a1] uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#eec14b] animate-ping" />
              <span>Inviolable Rule: Anuradhapura is Stop #1</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl text-[#e0e3e5]">
              {currentItinerary.title}
            </h3>
            <p className="text-xs sm:text-sm text-[#d1c5af] max-w-3xl font-light leading-relaxed">
              {currentItinerary.overview}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 shrink-0">
            <div className="flex flex-col text-left sm:text-right">
              <span className="text-[11px] text-[#9a907c] uppercase tracking-wider font-semibold">
                Selected Blueprint
              </span>
              <span className="font-serif text-xl sm:text-2xl text-[#eec14b] font-bold">
                {currentItinerary.duration}
              </span>
            </div>
            <a
              href={`https://wa.me/94702216999?text=${encodeURIComponent(
                `Hello Travel Zoom Tours, I would like to request the ${currentItinerary.title} commencing in Anuradhapura.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="py-2.5 px-4 rounded-lg bg-[#eec14b] text-[#3e2e00] text-xs font-bold uppercase tracking-wider hover:bg-[#ffdf98] transition-all shadow-md flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">chat</span>
              <span>Request Quote</span>
            </a>
          </div>
        </div>

        {/* Timeline Container */}
        <div className="relative pl-6 sm:pl-10 flex flex-col gap-6">
          {/* Vertical Spine Line */}
          <div className="absolute left-3 sm:left-5 top-5 bottom-5 w-0.5 bg-gradient-to-b from-[#eec14b] via-[#80d9a1] to-[#4e4635]" />

          {currentItinerary.days.map((item: DayPlan, index: number) => {
            const isFirst = index === 0;

            return (
              <div key={item.day} className="relative flex items-start gap-4 group">
                {/* Node Jewel Marker */}
                <div
                  className={`absolute -left-3 sm:-left-5 w-6 h-6 rounded-full flex items-center justify-center font-mono text-[11px] font-bold shadow-md z-10 ${
                    isFirst
                      ? 'bg-[#eec14b] text-[#3e2e00] ring-4 ring-[#eec14b]/20'
                      : 'bg-[#272a2c] border border-[#eec14b]/40 text-[#eec14b]'
                  }`}
                >
                  {item.day}
                </div>

                {/* Card Content */}
                <div className="w-full p-5 sm:p-6 rounded-2xl bg-[#191c1e] border border-[#272a2c] group-hover:border-[#eec14b]/30 transition-all shadow-md flex flex-col gap-3.5 ml-4 sm:ml-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-[#272a2c] pb-3">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                          isFirst ? 'bg-[#eec14b] text-[#3e2e00]' : 'bg-[#272a2c] text-[#eec14b]'
                        }`}
                      >
                        Day {item.day}
                      </span>
                      <h4 className="font-serif text-lg sm:text-xl text-[#e0e3e5]">{item.title}</h4>
                    </div>
                    <span className="text-xs text-[#9a907c] tracking-wider flex items-center gap-1 font-mono">
                      <span className="material-symbols-outlined text-[15px] text-[#eec14b]">schedule</span>
                      {item.driveTime}
                    </span>
                  </div>

                  {/* Route details */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-[#d1c5af] p-3 rounded-lg bg-[#101415] border border-[#272a2c]">
                    <div>
                      <strong className="text-[#e0e3e5]">Starting:</strong> {item.start}
                    </div>
                    <div>
                      <strong className="text-[#e0e3e5]">Destination:</strong>{' '}
                      <span className={isFirst ? 'text-[#eec14b] font-bold' : ''}>{item.stop}</span>
                    </div>
                    <div>
                      <strong className="text-[#e0e3e5]">Overnight:</strong> {item.overnight}
                    </div>
                  </div>

                  {/* Activities */}
                  <div className="flex flex-col gap-1.5 pt-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#eec14b]">
                      Key Experiences & Sightseeing:
                    </span>
                    <ul className="list-none space-y-1.5 text-[#e0e3e5] text-xs font-light">
                      {item.activities.map((act, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="material-symbols-outlined text-[#80d9a1] text-[16px] shrink-0 mt-0.5">
                            check_circle
                          </span>
                          <span>{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Chauffeur Tips */}
                  <div className="p-3 rounded-lg bg-[#101415] border border-[#272a2c] text-xs text-[#d1c5af] flex items-start gap-2">
                    <span className="material-symbols-outlined text-[#eec14b] text-[18px] shrink-0 mt-0.5">
                      lightbulb
                    </span>
                    <span className="leading-relaxed">
                      <strong className="text-[#e0e3e5] font-semibold">Expert Chauffeur Tip:</strong> {item.tips}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
