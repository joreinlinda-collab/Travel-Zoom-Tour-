import React, { useState } from 'react';

interface HeroSectionProps {
  onQuickQuoteSubmit: (data: {
    arrivalDate: string;
    travelers: string;
    duration: string;
    travelStyle: string;
  }) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onQuickQuoteSubmit }) => {
  // Default to 14 days in future
  const getDefaultDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  };

  const [arrivalDate, setArrivalDate] = useState(getDefaultDate());
  const [travelers, setTravelers] = useState('2 Travelers (Couple / Duo)');
  const [duration, setDuration] = useState('7 Days (Ceylon Essence)');
  const [travelStyle, setTravelStyle] = useState('Private Chauffeur Tour');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onQuickQuoteSubmit({
      arrivalDate,
      travelers,
      duration,
      travelStyle,
    });
  };

  return (
    <section id="home" className="relative w-full overflow-hidden -mt-20 pt-20">
      <div
        className="relative w-full min-h-[920px] lg:min-h-[960px] flex items-center justify-center py-20 px-4 sm:px-6 lg:px-10 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuBvwaBc-RYVAZDTIe1VZluwoPaxA1Xj3C6XcJw2qb5-3DbcCJ7FICqqePuYdZHCN8A49cXRVZ52SSaHPFCxrfMlgPejZh2WbY4mir-vd_AaGnD30SNhB4qYud3IOOH40ybp-B_JthKXcY7-0i1eoyBWs_Q0zPHXnRrNowTzaWiR_4JAE3nwEf-AVcFgo1r1dXHwwFVzhBYCauSXjqFRgF5Pq10rTC8gjAvitzmeBnnJUZ2-UyXcX22w')`,
        }}
      >
        {/* Soft Contrast Gradient Scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#101415] via-[#101415]/85 to-[#0b0f10]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#eec14b]/10 via-transparent to-transparent pointer-events-none" />

        <div className="relative z-10 w-full max-w-7xl mx-auto flex flex-col items-center text-center gap-6 pt-12 sm:pt-8">
          {/* Royal Tag */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#272a2c]/80 border border-[#eec14b]/20 backdrop-blur-md shadow-lg">
            <span className="material-symbols-outlined text-[#eec14b] text-[18px]">verified</span>
            <span className="text-[11px] font-bold uppercase tracking-widest text-[#ffdf98]">
              SLTDA Certified • Bespoke Private Chauffeur Expeditions
            </span>
          </div>

          {/* Headline & Editorial Lead */}
          <div className="max-w-4xl flex flex-col gap-3">
            <h1 className="font-serif text-4xl sm:text-6xl lg:text-[66px] leading-[1.12] text-[#e0e3e5] tracking-tight">
              Discover the Wonder of <span className="italic text-[#eec14b] font-normal">Sri Lanka</span>
            </h1>
            <p className="text-base sm:text-lg text-[#d1c5af] max-w-3xl mx-auto font-light leading-relaxed">
              Explore ancient kingdoms, breathtaking landscapes, incredible wildlife, and authentic Sri Lankan culture with personalized tours designed around you. Every voyage begins in reverence at the ancient sacred capital of <strong className="text-[#eec14b] font-semibold">Anuradhapura</strong>.
            </p>
          </div>

          {/* Hero Actions */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-1">
            <a
              href="#packages"
              className="px-8 py-3.5 rounded-lg bg-[#eec14b] text-[#3e2e00] font-bold text-xs uppercase tracking-wider shadow-xl hover:bg-[#ffdf98] transition-all flex items-center gap-2"
            >
              <span>Explore Tour Packages</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </a>
            <a
              href="#contact"
              className="px-8 py-3.5 rounded-lg bg-[#272a2c]/90 text-[#e0e3e5] font-semibold text-xs uppercase tracking-wider hover:bg-[#323537] border border-[#d1c5af]/15 transition-all flex items-center gap-2 shadow-md"
            >
              <span className="material-symbols-outlined text-[18px] text-[#eec14b]">tune</span>
              <span>Plan Your Journey</span>
            </a>
          </div>

          {/* Floating Interactive Booking Inquiry Panel */}
          <div className="w-full max-w-5xl mt-6 rounded-2xl bg-[#191c1e]/95 border border-[#4e4635]/40 backdrop-blur-xl shadow-2xl p-5 sm:p-7 text-left">
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#272a2c]">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#eec14b] text-[20px]">explore</span>
                <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-[#e0e3e5]">
                  Curate Your Bespoke Itinerary
                </span>
              </div>
              <span className="text-xs font-semibold text-[#80d9a1] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#80d9a1] animate-pulse" />
                Instant WhatsApp Quotation
              </span>
            </div>

            <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
              {/* Start Date */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#d1c5af]">
                  Arrival Date
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[#9a907c] text-[18px] absolute left-3 pointer-events-none">
                    calendar_month
                  </span>
                  <input
                    type="date"
                    required
                    value={arrivalDate}
                    onChange={(e) => setArrivalDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] transition-colors"
                  />
                </div>
              </div>

              {/* Number of Travelers */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#d1c5af]">
                  Travelers
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[#9a907c] text-[18px] absolute left-3 pointer-events-none">
                    group
                  </span>
                  <select
                    value={travelers}
                    onChange={(e) => setTravelers(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] transition-colors appearance-none"
                  >
                    <option value="1 Solo Traveler">1 Solo Traveler</option>
                    <option value="2 Travelers (Couple / Duo)">2 Travelers (Couple / Duo)</option>
                    <option value="3-4 Travelers (Family / Small Group)">3-4 Travelers (Family)</option>
                    <option value="5-8 Travelers (Private Group)">5-8 Travelers (Private Group)</option>
                    <option value="9+ Travelers (Large Delegation)">9+ Travelers (Large Group)</option>
                  </select>
                </div>
              </div>

              {/* Preferred Duration */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#d1c5af]">
                  Tour Duration
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[#9a907c] text-[18px] absolute left-3 pointer-events-none">
                    schedule
                  </span>
                  <select
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] transition-colors appearance-none"
                  >
                    <option value="3 Days (Cultural Discovery)">3 Days</option>
                    <option value="5 Days (Cultural Highlights)">5 Days</option>
                    <option value="7 Days (Ceylon Essence)">7 Days</option>
                    <option value="10 Days (Heritage & Hill Country)">10 Days</option>
                    <option value="15 Days (Grand Island Odyssey)">15 Days</option>
                    <option value="20 Days (Deep Wilderness Odyssey)">20 Days</option>
                    <option value="30 Days (Extended Ceylon Immersion)">30 Days</option>
                  </select>
                </div>
              </div>

              {/* Travel Style */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-semibold uppercase tracking-wider text-[#d1c5af]">
                  Travel Style
                </label>
                <div className="relative flex items-center">
                  <span className="material-symbols-outlined text-[#9a907c] text-[18px] absolute left-3 pointer-events-none">
                    loyalty
                  </span>
                  <select
                    value={travelStyle}
                    onChange={(e) => setTravelStyle(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] transition-colors appearance-none"
                  >
                    <option value="Private Chauffeur Tour">Private Chauffeur</option>
                    <option value="Couples & Honeymoon">Couples & Honeymoon</option>
                    <option value="Family Expeditions">Family Expedition</option>
                    <option value="Cultural & Heritage">Cultural & Heritage</option>
                    <option value="Wildlife & Safari">Wildlife & Safari</option>
                    <option value="Solo Explorer">Solo Explorer</option>
                    <option value="Senior-Friendly Comfort">Senior Comfort</option>
                    <option value="Bespoke Luxury Holidays">Bespoke Luxury</option>
                  </select>
                </div>
              </div>

              {/* Submit CTA */}
              <div className="flex flex-col justify-end">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-lg bg-[#eec14b] text-[#3e2e00] font-bold text-xs uppercase tracking-wider hover:bg-[#ffdf98] transition-all shadow-lg flex items-center justify-center gap-1.5 h-[42px]"
                >
                  <span className="material-symbols-outlined text-[18px]">send</span>
                  <span>Check Availability</span>
                </button>
              </div>
            </form>

            {/* Bottom Meta & Golden Rule Notice */}
            <div className="mt-4 pt-3 border-t border-[#272a2c] flex flex-wrap items-center justify-between gap-2.5 text-[#d1c5af] text-xs">
              <div className="flex items-center gap-1.5 text-[#eec14b] font-medium">
                <span className="material-symbols-outlined text-[17px]">pin_drop</span>
                <span>All itineraries commence with Anuradhapura heritage sanctuary</span>
              </div>
              <div className="flex items-center gap-4 text-[11px]">
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px] text-[#80d9a1]">check_circle</span>
                  No Hidden Chauffeur Fees
                </span>
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px] text-[#80d9a1]">check_circle</span>
                  100% Tailor-Made
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
