import React from 'react';
import { DESTINATION_REGIONS, DestinationRegion } from '../data/toursData';

export const DestinationsSection: React.FC = () => {
  return (
    <section id="destinations" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#0b0f10]">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        <div className="flex flex-col gap-2">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Island Geography
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Iconic Regions of Sri Lanka
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed max-w-2xl">
            From the ancient dry-zone capitals of the north to the misted cloud forests of the central massif and the sun-bleached ramparts of Galle.
          </p>
        </div>

        {/* Bento-style Destination Layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {DESTINATION_REGIONS.map((dest: DestinationRegion) => {
            if (dest.isHeroAnchor) {
              return (
                <div
                  key={dest.id}
                  className="md:col-span-2 rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-xl flex flex-col justify-between min-h-[380px] sm:min-h-[420px] relative group"
                >
                  <img
                    src={dest.image}
                    alt={dest.imageAlt}
                    className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101415] via-[#101415]/65 to-transparent" />

                  <div className="relative z-10 p-6 flex justify-between items-start">
                    <span className="px-3 py-1 rounded bg-[#eec14b] text-[#3e2e00] text-[11px] font-bold uppercase tracking-wider shadow-md">
                      Priority First Stop
                    </span>
                    <span className="text-xs text-[#e0e3e5] bg-[#272a2c]/85 px-3 py-1 rounded-lg backdrop-blur-md border border-[#4e4635]/40 font-medium">
                      {dest.region}
                    </span>
                  </div>

                  <div className="relative z-10 p-6 sm:p-8 flex flex-col gap-2">
                    <h3 className="font-serif text-2xl sm:text-3xl text-[#e0e3e5]">{dest.title}</h3>
                    <p className="text-xs sm:text-sm text-[#d1c5af] font-light max-w-xl leading-relaxed">
                      {dest.description}
                    </p>
                    <div className="flex items-center gap-4 pt-2 text-xs font-semibold text-[#eec14b] uppercase tracking-wider">
                      <span>{dest.meta}</span>
                    </div>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={dest.id}
                className="rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-lg flex flex-col justify-between min-h-[340px] relative group"
              >
                <img
                  src={dest.image}
                  alt={dest.imageAlt}
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#101415] via-[#101415]/65 to-transparent" />

                <div className="relative z-10 p-5">
                  <span className="text-xs text-[#e0e3e5] bg-[#272a2c]/85 px-2.5 py-1 rounded-lg backdrop-blur-md border border-[#4e4635]/40 font-medium">
                    {dest.region}
                  </span>
                </div>

                <div className="relative z-10 p-5 sm:p-6 flex flex-col gap-1.5">
                  <h3 className="font-serif text-xl sm:text-2xl text-[#e0e3e5]">{dest.title}</h3>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed">
                    {dest.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
