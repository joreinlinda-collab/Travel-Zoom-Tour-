import React from 'react';
import { REVIEWS_LIST, ReviewItem } from '../data/toursData';

export const ReviewsSection: React.FC = () => {
  return (
    <section id="reviews" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#101415]">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        {/* Google Trust Header */}
        <div className="p-6 sm:p-10 rounded-3xl bg-[#191c1e] border border-[#272a2c] shadow-2xl flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="flex flex-col gap-2 text-center lg:text-left">
            <div className="inline-flex items-center justify-center lg:justify-start gap-3">
              <div className="flex items-center text-[#eec14b]">
                {[1, 2, 3, 4, 5].map((s) => (
                  <span key={s} className="material-symbols-outlined text-[22px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    star
                  </span>
                ))}
              </div>
              <span className="font-serif text-2xl text-[#e0e3e5] font-bold">5.0 / 5.0</span>
              <span className="text-xs uppercase tracking-wider text-[#eec14b] font-bold">
                Verified Google Reviews
              </span>
            </div>
            <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl text-[#e0e3e5]">
              Real Traveler Feedback on Google
            </h2>
            <p className="text-xs sm:text-sm text-[#d1c5af] font-light max-w-xl leading-relaxed">
              We value genuine transparency. Every review below is published independently by verified international travelers on our official Google Business Profile.
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <a
              href="https://share.google/B3ZVi1JxOJn7LIhCR"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-xl bg-[#eec14b] text-[#3e2e00] text-xs font-bold uppercase tracking-wider hover:bg-[#ffdf98] transition-all shadow-md flex items-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">rate_review</span>
              <span>Read Google Reviews</span>
            </a>
            <a
              href="https://share.google/B3ZVi1JxOJn7LIhCR"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-3 rounded-xl bg-[#272a2c] hover:bg-[#323537] text-[#e0e3e5] text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-2 border border-[#4e4635]/40"
            >
              <span className="material-symbols-outlined text-[18px] text-[#eec14b]">edit_note</span>
              <span>Leave a Google Review</span>
            </a>
          </div>
        </div>

        {/* Real Client Testimonial Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {REVIEWS_LIST.map((review: ReviewItem) => (
            <div
              key={review.id}
              className="p-6 rounded-2xl bg-[#191c1e] border border-[#272a2c] shadow-md flex flex-col justify-between gap-5 group hover:border-[#eec14b]/30 transition-all"
            >
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-0.5 text-[#eec14b]">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <span key={s} className="material-symbols-outlined text-[17px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                        star
                      </span>
                    ))}
                  </div>
                  <span className="text-[11px] text-[#9a907c] font-medium">{review.timeAgo}</span>
                </div>
                <p className="text-xs sm:text-sm text-[#e0e3e5] italic font-light leading-relaxed">
                  {review.comment}
                </p>
              </div>

              <div className="flex items-center gap-3 pt-3 border-t border-[#272a2c]">
                <div className="w-10 h-10 rounded-full bg-[#272a2c] border border-[#eec14b]/30 flex items-center justify-center text-[#eec14b] font-bold text-xs">
                  {review.initials}
                </div>
                <div className="flex flex-col">
                  <span className="text-xs text-[#e0e3e5] font-semibold">{review.name}</span>
                  <span className="text-[11px] text-[#9a907c]">{review.locationAndTrip}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
