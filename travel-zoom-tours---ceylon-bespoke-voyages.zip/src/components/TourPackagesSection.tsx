import React from 'react';
import { TOUR_PACKAGES, TourPackage } from '../data/toursData';

interface TourPackagesSectionProps {
  selectedDurationGroup: string;
  onSelectDurationGroup: (group: string) => void;
  selectedStyle: string;
  onSelectStyle: (style: string) => void;
  onViewItinerary: (days: number) => void;
}

export const TourPackagesSection: React.FC<TourPackagesSectionProps> = ({
  selectedDurationGroup,
  onSelectDurationGroup,
  selectedStyle,
  onSelectStyle,
  onViewItinerary,
}) => {
  const filteredPackages = TOUR_PACKAGES.filter((pkg) => {
    // Filter duration
    let durationMatch = false;
    if (selectedDurationGroup === 'all') durationMatch = true;
    else if (selectedDurationGroup === '3-5' && (pkg.days === 3 || pkg.days === 5)) durationMatch = true;
    else if (selectedDurationGroup === '7-10' && (pkg.days === 7 || pkg.days === 10)) durationMatch = true;
    else if (selectedDurationGroup === '15-20' && (pkg.days === 15 || pkg.days === 20)) durationMatch = true;
    else if (selectedDurationGroup === '30' && pkg.days === 30) durationMatch = true;

    // Filter style
    let styleMatch = false;
    if (selectedStyle === 'all' || pkg.styles.includes(selectedStyle)) {
      styleMatch = true;
    }

    return durationMatch && styleMatch;
  });

  return (
    <section id="packages" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#0b0f10]">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        {/* Header with Golden Rule Announcement */}
        <div className="flex flex-col gap-3 text-center max-w-3xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Sri Lanka Signature Itineraries
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Curated Private Chauffeur Voyages
          </h2>

          {/* Sacred Starting Point Highlight Banner */}
          <div className="mt-2 inline-flex items-center justify-center gap-3 p-3.5 rounded-xl bg-[#272a2c]/80 border-l-4 border-[#eec14b] text-left shadow-md">
            <span className="material-symbols-outlined text-[#eec14b] text-[22px] shrink-0">
              account_balance
            </span>
            <p className="text-xs sm:text-sm text-[#e0e3e5] leading-relaxed">
              <strong className="text-[#eec14b] font-semibold">Travel Zoom Golden Heritage Rule:</strong> Every bespoke Sri Lankan voyage begins with airport welcome and an immediate private journey to the ancient sacred city of <span className="text-[#ffdf98] underline font-semibold">Anuradhapura</span> before continuing into the central highlands and coastal shores.
            </p>
          </div>
        </div>

        {/* Filter Controls: Duration Tabs + Persona Select */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-2.5 rounded-2xl bg-[#191c1e] border border-[#272a2c]">
          {/* Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            {[
              { id: 'all', label: 'All Voyages' },
              { id: '3-5', label: '3 - 5 Days' },
              { id: '7-10', label: '7 - 10 Days' },
              { id: '15-20', label: '15 - 20 Days' },
              { id: '30', label: '30 Days' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectDurationGroup(tab.id)}
                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                  selectedDurationGroup === tab.id
                    ? 'bg-[#eec14b] text-[#3e2e00] shadow-md'
                    : 'text-[#d1c5af] hover:text-[#eec14b] hover:bg-[#272a2c]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Style Dropdown Filter */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs text-[#d1c5af] uppercase tracking-wider hidden sm:inline font-semibold">
              Style:
            </span>
            <select
              value={selectedStyle}
              onChange={(e) => onSelectStyle(e.target.value)}
              className="w-full md:w-64 px-4 py-2 rounded-lg bg-[#101415] border border-[#4e4635]/60 text-[#e0e3e5] text-xs focus:outline-none focus:border-[#eec14b] transition-colors"
            >
              <option value="all">All Traveler Styles</option>
              <option value="Private Tours">Private Chauffeur Tours</option>
              <option value="Couples & Honeymoon">Couples & Honeymoon</option>
              <option value="Family Expeditions">Family Expeditions</option>
              <option value="Cultural & Heritage">Cultural & Heritage</option>
              <option value="Wildlife & Safari">Wildlife & Safari</option>
              <option value="Solo Explorers">Solo Explorers</option>
              <option value="Senior-Friendly Comfort">Senior-Friendly Comfort</option>
              <option value="Bespoke Holidays">Bespoke Luxury</option>
            </select>
          </div>
        </div>

        {/* Empty State */}
        {filteredPackages.length === 0 && (
          <div className="p-12 text-center rounded-2xl bg-[#191c1e] border border-[#272a2c] flex flex-col items-center gap-3">
            <span className="material-symbols-outlined text-4xl text-[#eec14b]">travel_explore</span>
            <p className="text-sm text-[#e0e3e5]">No tour packages match the selected duration and traveler style.</p>
            <button
              onClick={() => {
                onSelectDurationGroup('all');
                onSelectStyle('all');
              }}
              className="mt-2 px-4 py-2 rounded-lg bg-[#eec14b] text-[#3e2e00] text-xs font-bold uppercase"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Package Cards Mosaic */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPackages.map((pkg: TourPackage) => {
            const isThirtyDay = pkg.days === 30;

            if (isThirtyDay) {
              return (
                <article
                  key={pkg.id}
                  className="group rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-xl flex flex-col justify-between transition-all hover:-translate-y-1 md:col-span-2 lg:col-span-3"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
                    <div className="lg:col-span-5 relative min-h-[280px] lg:min-h-full overflow-hidden">
                      <img
                        src={pkg.image}
                        alt={pkg.imageAlt}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t lg:bg-gradient-to-r from-[#191c1e] via-transparent to-black/30" />
                      <div className="absolute top-3 left-3 px-3 py-1 rounded bg-[#323537]/90 backdrop-blur-md text-[#eec14b] text-[11px] font-bold uppercase tracking-wider">
                        {pkg.days} Days / {pkg.nights} Nights
                      </div>
                      <div className="absolute top-3 right-3 px-3 py-1 rounded bg-[#5ab27d]/90 text-[#00391e] text-[11px] font-bold uppercase tracking-wider">
                        {pkg.category}
                      </div>
                    </div>

                    <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between gap-5">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-2 text-xs font-semibold text-[#80d9a1] uppercase tracking-wider">
                          <span className="w-2 h-2 rounded-full bg-[#eec14b] animate-ping" />
                          <span>Stop #1: Inviolable Anchor • Sacred Anuradhapura • Days 1-3</span>
                        </div>
                        <h3 className="font-serif text-2xl sm:text-3xl text-[#e0e3e5]">{pkg.title}</h3>

                        {/* Route Line */}
                        <div className="p-3 rounded-lg bg-[#101415] border border-[#272a2c] text-xs text-[#d1c5af] flex items-center gap-1.5 flex-wrap">
                          {pkg.routeStops.map((stop, i) => (
                            <React.Fragment key={stop}>
                              <span className={i === 0 ? 'text-[#eec14b] font-bold' : ''}>{stop}</span>
                              {i < pkg.routeStops.length - 1 && (
                                <span className="material-symbols-outlined text-[14px] text-[#9a907c]">arrow_right_alt</span>
                              )}
                            </React.Fragment>
                          ))}
                        </div>

                        <p className="text-sm text-[#d1c5af] font-light leading-relaxed">
                          {pkg.description}
                        </p>
                      </div>

                      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2 border-t border-[#272a2c]">
                        <div>
                          <span className="text-[11px] text-[#9a907c] uppercase tracking-wider block font-medium">
                            Fully Customizable Expedition
                          </span>
                          <span className="font-serif text-xl text-[#eec14b] font-semibold">
                            {pkg.priceNote}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <button
                            type="button"
                            onClick={() => onViewItinerary(pkg.days)}
                            className="flex-1 sm:flex-initial py-2.5 px-5 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#e0e3e5] text-xs font-bold uppercase tracking-wider text-center transition-colors border border-[#4e4635]/50"
                          >
                            Full 30-Day Blueprint
                          </button>
                          <a
                            href={`https://wa.me/94702216999?text=${encodeURIComponent(
                              `Hello Travel Zoom Tours, I am interested in the ${pkg.title} starting in Anuradhapura. Please provide details and pricing.`
                            )}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 sm:flex-initial py-2.5 px-5 rounded-lg bg-[#eec14b] hover:bg-[#ffdf98] text-[#3e2e00] text-xs font-bold uppercase tracking-wider text-center flex items-center justify-center gap-1.5 transition-colors shadow-lg"
                          >
                            <span className="material-symbols-outlined text-[17px]">chat</span>
                            <span>Inquire on WhatsApp</span>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </article>
              );
            }

            return (
              <article
                key={pkg.id}
                className="group rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-lg flex flex-col justify-between transition-all hover:-translate-y-1"
              >
                <div>
                  <div className="relative w-full h-56 overflow-hidden">
                    <img
                      src={pkg.image}
                      alt={pkg.imageAlt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#191c1e] via-transparent to-black/30" />
                    <div className="absolute top-3 left-3 px-3 py-1 rounded bg-[#323537]/90 backdrop-blur-md text-[#eec14b] text-[11px] font-bold uppercase tracking-wider">
                      {pkg.days} Days / {pkg.nights} Nights
                    </div>
                    {pkg.tag ? (
                      <div className="absolute top-3 right-3 px-3 py-1 rounded bg-[#eec14b] text-[#3e2e00] text-[11px] font-bold uppercase tracking-wider">
                        {pkg.tag}
                      </div>
                    ) : (
                      <div className="absolute top-3 right-3 px-3 py-1 rounded bg-[#5ab27d]/90 text-[#00391e] text-[11px] font-bold uppercase tracking-wider">
                        {pkg.category}
                      </div>
                    )}
                  </div>

                  <div className="p-5 sm:p-6 flex flex-col gap-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-[#80d9a1] uppercase tracking-wider">
                      <span className="w-2 h-2 rounded-full bg-[#eec14b] animate-ping" />
                      <span>Stop #1: Sacred Anuradhapura</span>
                    </div>

                    <h3 className="font-serif text-xl sm:text-2xl text-[#e0e3e5]">{pkg.title}</h3>

                    {/* Route Flow with Anuradhapura 1st */}
                    <div className="p-2.5 rounded-lg bg-[#101415] border border-[#272a2c] text-xs text-[#d1c5af] flex items-center gap-1.5 flex-wrap">
                      {pkg.routeStops.map((stop, i) => (
                        <React.Fragment key={stop}>
                          <span className={i === 0 ? 'text-[#eec14b] font-bold' : ''}>{stop}</span>
                          {i < pkg.routeStops.length - 1 && (
                            <span className="material-symbols-outlined text-[13px] text-[#9a907c]">arrow_right_alt</span>
                          )}
                        </React.Fragment>
                      ))}
                    </div>

                    <p className="text-xs sm:text-sm text-[#d1c5af] font-light leading-relaxed">
                      {pkg.description}
                    </p>
                  </div>
                </div>

                <div className="p-5 sm:p-6 pt-0 flex flex-col gap-3">
                  <div className="flex items-center justify-between text-xs text-[#d1c5af] border-t border-[#272a2c] pt-3">
                    <span>Private Chauffeur Tour</span>
                    <span className="text-[#eec14b] font-bold text-xs uppercase">{pkg.priceNote}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => onViewItinerary(pkg.days)}
                      className="w-full py-2 px-3 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#e0e3e5] text-xs font-bold uppercase tracking-wider text-center transition-colors border border-[#4e4635]/40"
                    >
                      View Itinerary
                    </button>
                    <a
                      href={`https://wa.me/94702216999?text=${encodeURIComponent(
                        `Hello Travel Zoom Tours, I am interested in the ${pkg.title} starting in Anuradhapura.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-2 px-3 rounded-lg bg-[#eec14b] hover:bg-[#ffdf98] text-[#3e2e00] text-xs font-bold uppercase tracking-wider text-center flex items-center justify-center gap-1 transition-colors shadow-md"
                    >
                      <span className="material-symbols-outlined text-[16px]">chat</span>
                      <span>WhatsApp</span>
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};
