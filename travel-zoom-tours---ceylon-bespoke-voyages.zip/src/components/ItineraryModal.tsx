import React, { useEffect } from 'react';
import { ITINERARY_DATA, DayPlan } from '../data/toursData';

interface ItineraryModalProps {
  days: number | null;
  onClose: () => void;
}

export const ItineraryModal: React.FC<ItineraryModalProps> = ({ days, onClose }) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!days) return null;

  const data = ITINERARY_DATA[days] || ITINERARY_DATA[7];

  const handlePrint = () => {
    window.print();
  };

  const waLink = `https://wa.me/94702216999?text=${encodeURIComponent(
    `Hello Travel Zoom Tours, I am interested in the ${data.title} commencing in Anuradhapura. Please provide a detailed quote.`
  )}`;

  return (
    <div className="fixed inset-0 z-50 bg-[#0b0f10]/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div
        className="w-full max-w-4xl max-h-[90vh] bg-[#191c1e] border border-[#272a2c] rounded-3xl shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 flex items-center justify-between border-b border-[#272a2c] bg-[#101415]/60">
          <div className="flex flex-col gap-0.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#eec14b]">
              Complete {data.duration} Blueprint
            </span>
            <h3 className="font-serif text-xl sm:text-2xl text-[#e0e3e5]">{data.title}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-[#272a2c] hover:bg-[#323537] flex items-center justify-center text-[#d1c5af] hover:text-[#e0e3e5] transition-colors"
            aria-label="Close Itinerary Modal"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-5 sm:p-7 overflow-y-auto flex flex-col gap-4">
          <div className="p-4 rounded-xl bg-[#101415] border border-[#eec14b]/30 flex flex-col gap-1.5 shadow-sm">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#eec14b] text-[18px]">verified</span>
              <span className="text-xs font-bold text-[#eec14b] uppercase tracking-wider">
                Priority First Destination Inviolable Mandate:
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#e0e3e5] leading-relaxed">
              All Travel Zoom Tours commence with direct airport pickup and journey directly to the ancient sacred city of <strong className="text-[#eec14b] font-bold">Anuradhapura</strong>.
            </p>
            <p className="text-xs text-[#d1c5af] font-light mt-1">
              {data.overview}
            </p>
          </div>

          <div className="flex flex-col gap-3 mt-1">
            {data.days.map((item: DayPlan) => (
              <div
                key={item.day}
                className="p-4 sm:p-5 rounded-xl bg-[#101415] border border-[#272a2c] flex flex-col gap-2 hover:border-[#eec14b]/20 transition-colors"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#eec14b]">
                    Day {item.day}: {item.title}
                  </span>
                  <span className="text-[11px] text-[#9a907c] font-mono flex items-center gap-1">
                    <span className="material-symbols-outlined text-[13px] text-[#eec14b]">schedule</span>
                    {item.driveTime}
                  </span>
                </div>

                <div className="text-xs text-[#d1c5af] flex flex-wrap gap-x-4 gap-y-1">
                  <span>
                    <strong className="text-[#e0e3e5]">Destinations:</strong> {item.stop}
                  </span>
                  <span>
                    <strong className="text-[#e0e3e5]">Overnight:</strong> {item.overnight}
                  </span>
                </div>

                <ul className="mt-1 space-y-1 text-xs text-[#e0e3e5] font-light">
                  {item.activities.map((a, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#eec14b] shrink-0 mt-1.5" />
                      <span>{a}</span>
                    </li>
                  ))}
                </ul>

                <div className="text-[11px] text-[#d1c5af] pt-1 border-t border-[#272a2c] flex items-center gap-1.5 italic">
                  <span className="material-symbols-outlined text-[#eec14b] text-[15px] shrink-0">lightbulb</span>
                  <span>Tip: {item.tips}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-[#101415] border-t border-[#272a2c] flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-xs text-[#d1c5af] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[17px] text-[#80d9a1]">check_circle</span>
            <span>Stop #1 is Sacred Anuradhapura</span>
          </span>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#e0e3e5] text-xs font-bold uppercase tracking-wider transition-colors"
            >
              Print
            </button>
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-initial px-5 py-2 rounded-lg bg-[#eec14b] hover:bg-[#ffdf98] text-[#3e2e00] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors shadow-md"
            >
              <span className="material-symbols-outlined text-[17px]">chat</span>
              <span>Request This Tour</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
