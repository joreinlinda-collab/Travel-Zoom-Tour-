import React from 'react';

export const FloatingConcierge: React.FC = () => {
  return (
    <aside className="fixed bottom-6 right-6 z-40 group flex items-center gap-3">
      <div className="hidden sm:flex items-center px-4 py-2 rounded-full bg-[#272a2c]/95 border border-[#80d9a1]/30 backdrop-blur-md shadow-2xl text-[#e0e3e5] text-xs font-semibold tracking-wide">
        <span className="w-2 h-2 rounded-full bg-[#80d9a1] mr-2 animate-ping" />
        <span>Concierge Active • Chat live</span>
      </div>
      <a
        className="w-14 h-14 rounded-full bg-[#80d9a1] text-[#00391e] flex items-center justify-center shadow-[0_8px_24px_rgba(128,217,161,0.35)] hover:scale-105 active:scale-95 transition-all"
        href="https://wa.me/94702216999"
        rel="noopener noreferrer"
        target="_blank"
        title="WhatsApp Live Concierge"
        aria-label="Contact Travel Zoom Tours Concierge on WhatsApp"
      >
        <span className="material-symbols-outlined text-[28px]">chat</span>
      </a>
    </aside>
  );
};
