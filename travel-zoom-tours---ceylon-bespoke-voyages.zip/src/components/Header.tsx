import React, { useState } from 'react';

interface HeaderProps {
  onPlanTripClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onPlanTripClick }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Tour Packages', href: '#packages' },
    { label: 'Tour Itineraries', href: '#itineraries' },
    { label: 'Transport & Guides', href: '#transport' },
    { label: 'Activities', href: '#activities' },
    { label: 'Destinations', href: '#destinations' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact Us', href: '#contact' },
  ];

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#101415]/90 backdrop-blur-xl border-b border-[#272a2c]/60 shadow-[0_1px_12px_rgba(0,0,0,0.4)]">
        <div className="h-20 w-full px-4 sm:px-6 lg:px-10 flex items-center justify-between gap-6 max-w-7xl mx-auto">
          {/* Brand Logo and Title */}
          <div className="flex items-center gap-3">
            <img
              alt="Travel Zoom Tours Logo"
              className="h-9 w-auto object-contain"
              src="https://lh3.googleusercontent.com/aida/AEtjO1X4OpVaoaVtXVGHE8VQBKwm1j132l2-Li2iTmI7KfmaKncDTNGE_1RXlPOTaatOqV95b0qWjpxBld1xAfJEpyR_WPOYJqibCAMC3K8_sFsr41lwZYe7ypYYdRcVq7W-83bDxfsUFHjiq5j2JHne4b0XkFgiUuQvjF7KECYRGUHsTVda7USFn0xVkIqVZBLV-gQl4TUAvys6VfocnPYNnCDw8W316dQ-2wMWp9WLHKRAX4mcPjaHx9XFbg"
            />
            <a href="#home" className="flex flex-col text-left group">
              <span className="font-serif text-lg sm:text-xl tracking-wide text-[#eec14b] uppercase font-semibold leading-tight group-hover:text-[#ffdf98] transition-colors">
                Travel Zoom Tours
              </span>
              <span className="text-[10px] tracking-widest text-[#d1c5af] uppercase font-semibold">
                Ceylon Bespoke Voyages
              </span>
            </a>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-5">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-xs font-semibold uppercase tracking-wider text-[#d1c5af] hover:text-[#eec14b] transition-colors py-1 whitespace-nowrap"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Header Action CTAs */}
          <div className="flex items-center gap-3">
            <a
              className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#272a2c] hover:bg-[#323537] text-[#80d9a1] border border-[#80d9a1]/20 transition-all text-xs font-semibold tracking-wider uppercase whitespace-nowrap"
              href="https://wa.me/94702216999"
              rel="noopener noreferrer"
              target="_blank"
              title="Chat directly with our Ceylon travel specialist"
            >
              <span className="material-symbols-outlined text-[17px]">chat</span>
              <span>+94 70 221 6999</span>
            </a>

            <button
              onClick={onPlanTripClick}
              className="px-4 py-2 rounded-lg bg-[#eec14b] text-[#3e2e00] hover:bg-[#ffdf98] transition-all text-xs font-bold uppercase tracking-wider shadow-[0_0_20px_rgba(197,155,39,0.25)] whitespace-nowrap"
            >
              Plan Your Trip
            </button>

            <a
              href="#contact"
              className="w-9 h-9 rounded-full bg-[#eec14b] hover:bg-[#ffdf98] transition-colors flex items-center justify-center text-[#3e2e00] shadow-sm"
              title="Traveler Profile & Custom Inquiries"
            >
              <span className="material-symbols-outlined text-[18px]">person</span>
            </a>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="xl:hidden flex items-center justify-center p-2 rounded-lg text-[#d1c5af] hover:text-[#eec14b] hover:bg-[#272a2c] transition-colors"
              aria-label="Open Navigation Menu"
            >
              <span className="material-symbols-outlined text-[26px]">menu</span>
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Backdrop and Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 xl:hidden">
          <div
            className="fixed inset-0 bg-[#0b0f10]/80 backdrop-blur-md transition-opacity"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="fixed right-0 top-0 bottom-0 w-80 max-w-[85vw] bg-[#191c1e] border-l border-[#272a2c] p-6 flex flex-col justify-between shadow-2xl z-10 overflow-y-auto">
            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between pb-4 border-b border-[#272a2c]">
                <div className="flex items-center gap-2.5">
                  <img
                    alt="Travel Zoom Tours Logo"
                    className="h-8 w-auto object-contain"
                    src="https://lh3.googleusercontent.com/aida/AEtjO1X4OpVaoaVtXVGHE8VQBKwm1j132l2-Li2iTmI7KfmaKncDTNGE_1RXlPOTaatOqV95b0qWjpxBld1xAfJEpyR_WPOYJqibCAMC3K8_sFsr41lwZYe7ypYYdRcVq7W-83bDxfsUFHjiq5j2JHne4b0XkFgiUuQvjF7KECYRGUHsTVda7USFn0xVkIqVZBLV-gQl4TUAvys6VfocnPYNnCDw8W316dQ-2wMWp9WLHKRAX4mcPjaHx9XFbg"
                  />
                  <span className="font-serif text-lg text-[#eec14b] font-semibold">Travel Zoom</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-1.5 text-[#d1c5af] hover:text-[#e0e3e5] rounded-lg hover:bg-[#272a2c]"
                  aria-label="Close Navigation Menu"
                >
                  <span className="material-symbols-outlined text-[22px]">close</span>
                </button>
              </div>

              <nav className="flex flex-col gap-2">
                {navLinks.map((link) => (
                  <a
                    key={link.label}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="text-sm font-semibold uppercase tracking-wider text-[#d1c5af] hover:text-[#eec14b] hover:bg-[#272a2c]/50 px-3 py-2.5 rounded-lg transition-colors"
                  >
                    {link.label}
                  </a>
                ))}
              </nav>
            </div>

            <div className="flex flex-col gap-3 pt-6 border-t border-[#272a2c]">
              <a
                className="flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#272a2c] text-[#80d9a1] text-xs font-semibold tracking-wider uppercase"
                href="https://wa.me/94702216999"
                rel="noopener noreferrer"
                target="_blank"
              >
                <span className="material-symbols-outlined text-[18px]">chat</span>
                <span>WhatsApp Concierge</span>
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onPlanTripClick();
                }}
                className="flex items-center justify-center py-2.5 rounded-lg bg-[#eec14b] text-[#3e2e00] font-bold text-xs uppercase tracking-wider shadow-md hover:bg-[#ffdf98] transition-colors"
              >
                Plan Your Trip
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
