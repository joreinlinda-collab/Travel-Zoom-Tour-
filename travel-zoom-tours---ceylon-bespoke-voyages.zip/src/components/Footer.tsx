import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full bg-[#0b0f10] border-t border-[#272a2c] py-16 sm:py-20 text-[#d1c5af]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 flex flex-col gap-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-10">
          {/* Col 1: Brand Info */}
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <img
                alt="Travel Zoom Tours Logo"
                className="h-8 w-auto object-contain"
                src="https://lh3.googleusercontent.com/aida/AEtjO1X4OpVaoaVtXVGHE8VQBKwm1j132l2-Li2iTmI7KfmaKncDTNGE_1RXlPOTaatOqV95b0qWjpxBld1xAfJEpyR_WPOYJqibCAMC3K8_sFsr41lwZYe7ypYYdRcVq7W-83bDxfsUFHjiq5j2JHne4b0XkFgiUuQvjF7KECYRGUHsTVda7USFn0xVkIqVZBLV-gQl4TUAvys6VfocnPYNnCDw8W316dQ-2wMWp9WLHKRAX4mcPjaHx9XFbg"
              />
              <span className="font-serif text-xl text-[#eec14b] font-bold">Travel Zoom</span>
            </div>
            <p className="text-xs sm:text-sm font-light leading-relaxed">
              Curators of luxury bespoke expeditions across Sri Lanka. Private charter transport, high-altitude Ceylon tea estates, and untamed coastal sanctuaries.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <a
                href="https://share.google/B3ZVi1JxOJn7LIhCR"
                target="_blank"
                rel="noopener noreferrer"
                className="px-3 py-1.5 rounded-lg bg-[#191c1e] text-[#eec14b] text-xs font-semibold hover:bg-[#272a2c] border border-[#4e4635]/40 transition-colors flex items-center gap-1.5"
              >
                <span className="material-symbols-outlined text-[16px]">star</span>
                <span>Google Business Profile (5.0 ★)</span>
              </a>
            </div>
          </div>

          {/* Col 2: Voyage Durations */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-[#eec14b]">
              Voyage Durations
            </span>
            <div className="flex flex-col gap-2 text-xs font-light">
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">3-Day Cultural Glimpse</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">5-Day Heritage & Wildlife</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">7-Day Classic Ceylon Essence</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">10-Day Highland & Coastline</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">15-Day Grand Island Odyssey</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">20-Day Deep Wilderness & Culture</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">30-Day Royal Ceylon Immersion</a>
            </div>
          </div>

          {/* Col 3: Navigation */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-[#eec14b]">
              Navigation
            </span>
            <nav className="flex flex-col gap-2 text-xs font-light">
              <a href="#home" className="hover:text-[#eec14b] transition-colors">Home Sanctuary</a>
              <a href="#packages" className="hover:text-[#eec14b] transition-colors">Curated Tour Packages</a>
              <a href="#itineraries" className="hover:text-[#eec14b] transition-colors">Day-by-Day Blueprints</a>
              <a href="#transport" className="hover:text-[#eec14b] transition-colors">Private Fleet & Chauffeurs</a>
              <a href="#activities" className="hover:text-[#eec14b] transition-colors">Bespoke Experiences</a>
              <a href="#destinations" className="hover:text-[#eec14b] transition-colors">Sanctuary Locations</a>
              <a href="#reviews" className="hover:text-[#eec14b] transition-colors">Traveler Testimonials</a>
            </nav>
          </div>

          {/* Col 4: Sri Lanka Operations */}
          <div className="flex flex-col gap-3">
            <span className="text-xs font-bold uppercase tracking-wider text-[#eec14b]">
              Sri Lanka Operations
            </span>
            <div className="flex flex-col gap-2.5 text-xs font-light">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#eec14b] shrink-0">location_on</span>
                <span>Colombo & Galle Concierge Desks</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#eec14b] shrink-0">call</span>
                <span>+94 70 221 6999</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[16px] text-[#eec14b] shrink-0">mail</span>
                <span>voyages@travelzoomtours.com</span>
              </div>
              <div className="flex items-center gap-2 text-[#80d9a1] font-medium pt-1">
                <span className="material-symbols-outlined text-[16px] shrink-0">verified</span>
                <span>SLTDA Registered Luxury Tour Operator</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Terms */}
        <div className="pt-6 border-t border-[#272a2c] flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-light">
          <p>© 2025 Travel Zoom Tours Sri Lanka. All bespoke rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="#contact" className="hover:text-[#eec14b] transition-colors">Privacy Policy</a>
            <a href="#contact" className="hover:text-[#eec14b] transition-colors">Terms of Service</a>
            <a href="#contact" className="hover:text-[#eec14b] transition-colors">Official Inquiries</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
