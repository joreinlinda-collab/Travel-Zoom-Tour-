import React from 'react';

interface BookingConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookingData: {
    fullName: string;
    email: string;
    phone: string;
    country: string;
    arrivalDate: string;
    travelers: string;
    selectedPackage: string;
    accommodation: string;
    notes?: string;
  } | null;
  onOpenWhatsApp: () => void;
}

export const BookingConfirmationModal: React.FC<BookingConfirmationModalProps> = ({
  isOpen,
  onClose,
  bookingData,
  onOpenWhatsApp,
}) => {
  if (!isOpen || !bookingData) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#0b0f10]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div
        className="w-full max-w-lg bg-[#191c1e] border border-[#eec14b]/40 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col gap-5 relative text-left"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#272a2c] flex items-center justify-center text-[#d1c5af] hover:text-[#e0e3e5]"
        >
          <span className="material-symbols-outlined text-[18px]">close</span>
        </button>

        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#80d9a1]/15 border border-[#80d9a1]/40 flex items-center justify-center text-[#80d9a1]">
            <span className="material-symbols-outlined text-[28px]">verified</span>
          </div>
          <div>
            <h3 className="font-serif text-2xl text-[#e0e3e5] font-semibold">
              Bespoke Inquiry Ready
            </h3>
            <span className="text-xs text-[#80d9a1] font-semibold uppercase tracking-wider">
              Travel Zoom Concierge Connected
            </span>
          </div>
        </div>

        <p className="text-xs sm:text-sm text-[#d1c5af] font-light leading-relaxed">
          Thank you, <strong className="text-[#e0e3e5]">{bookingData.fullName}</strong>. Your customized itinerary details have been structured. In accordance with the <strong className="text-[#eec14b]">Golden Heritage Rule</strong>, your journey commences in sacred <strong className="text-[#ffdf98]">Anuradhapura</strong>.
        </p>

        {/* Summary box */}
        <div className="p-4 rounded-xl bg-[#101415] border border-[#272a2c] flex flex-col gap-2 text-xs">
          <div className="flex justify-between border-b border-[#272a2c] pb-1.5">
            <span className="text-[#9a907c]">Selected Package:</span>
            <span className="text-[#eec14b] font-semibold text-right">{bookingData.selectedPackage}</span>
          </div>
          <div className="flex justify-between border-b border-[#272a2c] pb-1.5">
            <span className="text-[#9a907c]">First Destination:</span>
            <span className="text-[#80d9a1] font-bold">Anuradhapura (Stop #1)</span>
          </div>
          <div className="flex justify-between border-b border-[#272a2c] pb-1.5">
            <span className="text-[#9a907c]">Travelers:</span>
            <span className="text-[#e0e3e5]">{bookingData.travelers}</span>
          </div>
          <div className="flex justify-between border-b border-[#272a2c] pb-1.5">
            <span className="text-[#9a907c]">Estimated Arrival:</span>
            <span className="text-[#e0e3e5]">{bookingData.arrivalDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#9a907c]">Accommodation:</span>
            <span className="text-[#e0e3e5]">{bookingData.accommodation}</span>
          </div>
        </div>

        <div className="flex flex-col gap-2 pt-2">
          <button
            type="button"
            onClick={onOpenWhatsApp}
            className="w-full py-3.5 px-4 rounded-xl bg-[#eec14b] text-[#3e2e00] font-bold text-xs uppercase tracking-wider hover:bg-[#ffdf98] transition-all shadow-lg flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined text-[18px]">chat</span>
            <span>Launch WhatsApp & Chat with Tour Planner</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 rounded-xl bg-[#272a2c] text-[#d1c5af] hover:text-[#e0e3e5] font-semibold text-xs uppercase tracking-wider"
          >
            Return to Itinerary
          </button>
        </div>
      </div>
    </div>
  );
};
