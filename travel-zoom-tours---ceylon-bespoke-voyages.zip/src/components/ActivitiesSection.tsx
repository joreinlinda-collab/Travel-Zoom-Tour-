import React from 'react';
import { CURATED_ACTIVITIES, CuratedActivity } from '../data/toursData';

export const ActivitiesSection: React.FC = () => {
  return (
    <section id="activities" className="w-full py-16 sm:py-24 px-4 sm:px-6 lg:px-10 bg-[#101415]">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        <div className="flex flex-col gap-2 text-center max-w-3xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-widest text-[#eec14b]">
            Unforgettable Memories
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-[42px] text-[#e0e3e5]">
            Curated Experiences Across the Island
          </h2>
          <p className="text-sm text-[#d1c5af] font-light leading-relaxed">
            Hand-picked excursions seamlessly woven into your private itinerary with pre-reserved tickets, VIP access, and private local specialists.
          </p>
        </div>

        {/* Activities Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CURATED_ACTIVITIES.map((activity: CuratedActivity) => (
            <div
              key={activity.id}
              className="group rounded-2xl bg-[#191c1e] border border-[#272a2c] overflow-hidden shadow-lg flex flex-col justify-between hover:border-[#eec14b]/30 transition-all hover:-translate-y-1"
            >
              <div>
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={activity.image}
                    alt={activity.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <span
                    className={`absolute top-3 left-3 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider backdrop-blur-md ${
                      activity.badgeColor || 'bg-[#101415]/90 text-[#eec14b]'
                    }`}
                  >
                    {activity.badge}
                  </span>
                </div>

                <div className="p-5 flex flex-col gap-2">
                  <h3 className="font-serif text-xl text-[#e0e3e5] leading-snug">
                    {activity.title}
                  </h3>
                  <p className="text-xs text-[#d1c5af] font-light leading-relaxed">
                    {activity.description}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0 border-t border-[#272a2c]/60 mt-2">
                <span className="text-[11px] text-[#eec14b] font-semibold uppercase tracking-wider flex items-center gap-1.5 pt-3">
                  <span className="material-symbols-outlined text-[15px]">schedule</span>
                  {activity.durationTag}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
