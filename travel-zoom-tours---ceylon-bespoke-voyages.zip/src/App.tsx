/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { TravelerPersonasSection } from './components/TravelerPersonasSection';
import { TourPackagesSection } from './components/TourPackagesSection';
import { ItineraryTimelineSection } from './components/ItineraryTimelineSection';
import { TransportFleetSection } from './components/TransportFleetSection';
import { ActivitiesSection } from './components/ActivitiesSection';
import { DestinationsSection } from './components/DestinationsSection';
import { ReviewsSection } from './components/ReviewsSection';
import { AboutSection } from './components/AboutSection';
import { BookingSection, BookingFormData } from './components/BookingSection';
import { FaqSection } from './components/FaqSection';
import { ItineraryModal } from './components/ItineraryModal';
import { BookingConfirmationModal } from './components/BookingConfirmationModal';
import { FloatingConcierge } from './components/FloatingConcierge';
import { Footer } from './components/Footer';

export default function App() {
  const [selectedDurationGroup, setSelectedDurationGroup] = useState<string>('all');
  const [selectedStyle, setSelectedStyle] = useState<string>('all');
  const [activeTimelineDays, setActiveTimelineDays] = useState<number>(7);
  const [modalItineraryDays, setModalItineraryDays] = useState<number | null>(null);

  // Booking & confirmation modal state
  const [bookingModalData, setBookingModalData] = useState<BookingFormData | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState<boolean>(false);
  const [prefilledPackage, setPrefilledPackage] = useState<string>(
    '7-Day Cultural & Hill Country (Anuradhapura 1st)'
  );

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // When clicking on a persona, filter the packages and scroll to the section
  const handleSelectPersona = (style: string) => {
    setSelectedStyle(style);
    scrollToSection('packages');
  };

  // Quick quote submission from the hero panel
  const handleQuickQuoteSubmit = (data: {
    arrivalDate: string;
    travelers: string;
    duration: string;
    travelStyle: string;
  }) => {
    const message = `Hello Travel Zoom Tours, I would like to inquire about a bespoke Sri Lanka tour with private chauffeur.\n\n*Tour Details:*\n- Preferred Duration: ${data.duration}\n- Inviolable First Stop: Anuradhapura (Confirmed)\n- Arrival Date: ${data.arrivalDate || 'Flexible'}\n- Travelers: ${data.travelers}\n- Travel Style: ${data.travelStyle}\n\nPlease provide available vehicles and custom quotation.`;

    const waUrl = `https://wa.me/94702216999?text=${encodeURIComponent(message)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');

    // Populate confirmation modal
    setBookingModalData({
      fullName: 'Distinguished Guest',
      email: 'Connecting via WhatsApp',
      phone: '+94 70 221 6999',
      country: 'International Traveler',
      arrivalDate: data.arrivalDate,
      travelers: data.travelers,
      selectedPackage: data.duration,
      accommodation: '5-Star Luxury & Heritage Bungalows',
      notes: `Style: ${data.travelStyle}`,
    });
    setIsBookingModalOpen(true);
  };

  // Master Booking form submit
  const handleMasterBookingSubmit = (data: BookingFormData) => {
    const message = `*New Bespoke Inquiry - Travel Zoom Tours Sri Lanka*\n\n*Guest Details:*\n- Name: ${data.fullName}\n- Country: ${data.country}\n- Email: ${data.email}\n- WhatsApp: ${data.phone}\n\n*Voyage Configuration:*\n- Selected Package: ${data.selectedPackage}\n- Inviolable First Stop: Anuradhapura (Confirmed)\n- Estimated Arrival: ${data.arrivalDate || 'Flexible'}\n- Travelers: ${data.travelers}\n- Accommodation Preference: ${data.accommodation}\n\n*Special Requests:*\n${data.notes || 'None specified'}\n\nPlease contact me directly with a tailor-made proposal.`;

    const waUrl = `https://wa.me/94702216999?text=${encodeURIComponent(message)}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');

    setBookingModalData(data);
    setIsBookingModalOpen(true);
  };

  const handleOpenWhatsAppFromModal = () => {
    if (!bookingModalData) return;
    const message = `Hello Travel Zoom Tours, I have reviewed my inquiry for ${bookingModalData.selectedPackage} starting in Anuradhapura. Ready to finalize details!`;
    window.open(
      `https://wa.me/94702216999?text=${encodeURIComponent(message)}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const handleRequestRouteFromTimeline = (title: string) => {
    setPrefilledPackage(title);
    scrollToSection('contact');
  };

  return (
    <div className="min-h-screen bg-[#101415] text-[#e0e3e5] font-sans selection:bg-[#c59b27] selection:text-[#473500]">
      {/* Top Fixed Header */}
      <Header onPlanTripClick={() => scrollToSection('contact')} />

      {/* Main Content Sections */}
      <main className="w-full pt-20">
        {/* 1. Hero & Real-time Booking Inquiry Panel */}
        <HeroSection onQuickQuoteSubmit={handleQuickQuoteSubmit} />

        {/* 2. Signature Traveler Personas */}
        <TravelerPersonasSection onSelectPersona={handleSelectPersona} />

        {/* 3. Signature Tour Packages (3, 5, 7, 10, 15, 20, 30 Days) */}
        <TourPackagesSection
          selectedDurationGroup={selectedDurationGroup}
          onSelectDurationGroup={setSelectedDurationGroup}
          selectedStyle={selectedStyle}
          onSelectStyle={setSelectedStyle}
          onViewItinerary={(days) => {
            setModalItineraryDays(days);
            setActiveTimelineDays(days);
          }}
        />

        {/* 4. Interactive Day-by-Day Tour Itinerary Timeline */}
        <ItineraryTimelineSection
          activeDays={activeTimelineDays}
          onSelectDays={setActiveTimelineDays}
          onRequestRoute={handleRequestRouteFromTimeline}
        />

        {/* 5. Transport Fleet & Professional Guide Services */}
        <TransportFleetSection />

        {/* 6. Curated Activities & Experiences */}
        <ActivitiesSection />

        {/* 7. Sri Lanka Destinations & Regions Bento Grid */}
        <DestinationsSection />

        {/* 8. Reviews & Real Trust Center (Direct Google Verification) */}
        <ReviewsSection />

        {/* 9. About Travel Zoom Tours */}
        <AboutSection />

        {/* 10. Comprehensive Booking Inquiry & WhatsApp Engine */}
        <BookingSection
          initialPackage={prefilledPackage}
          onSubmitBooking={handleMasterBookingSubmit}
        />

        {/* 11. Interactive FAQ Accordion */}
        <FaqSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating Concierge Action */}
      <FloatingConcierge />

      {/* Detailed Itinerary Modal */}
      <ItineraryModal
        days={modalItineraryDays}
        onClose={() => setModalItineraryDays(null)}
      />

      {/* Booking Confirmation Dialog Modal */}
      <BookingConfirmationModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        bookingData={bookingModalData}
        onOpenWhatsApp={handleOpenWhatsAppFromModal}
      />
    </div>
  );
}
