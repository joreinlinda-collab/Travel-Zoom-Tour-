export interface DayPlan {
  day: number;
  title: string;
  start: string;
  stop: string;
  route: string;
  driveTime: string;
  overnight: string;
  activities: string[];
  tips: string;
}

export interface TourPackage {
  id: number;
  days: number;
  title: string;
  nights: number;
  category: string;
  tag?: string;
  durationGroup: '3-5' | '7-10' | '15-20' | '30';
  styles: string[];
  routeStops: string[];
  description: string;
  image: string;
  imageAlt: string;
  priceNote: string;
}

export interface ItineraryData {
  title: string;
  duration: string;
  overview: string;
  days: DayPlan[];
}

export interface TravelerPersona {
  id: string;
  number: string;
  title: string;
  icon: string;
  description: string;
  filterStyle: string;
}

export interface FleetVehicle {
  id: string;
  title: string;
  capacity: string;
  model: string;
  image: string;
  imageAlt: string;
  description: string;
  features: string[];
}

export interface CuratedActivity {
  id: string;
  title: string;
  badge: string;
  badgeColor?: string;
  image: string;
  imageAlt: string;
  description: string;
  durationTag: string;
}

export interface DestinationRegion {
  id: string;
  title: string;
  region: string;
  image: string;
  imageAlt: string;
  description: string;
  meta: string;
  isHeroAnchor?: boolean;
}

export interface ReviewItem {
  id: string;
  name: string;
  locationAndTrip: string;
  timeAgo: string;
  rating: number;
  comment: string;
  initials: string;
}

export interface FaqItem {
  id: number;
  question: string;
  answer: string;
}

export const ITINERARY_DATA: Record<number, ItineraryData> = {
  3: {
    title: "3-Day Cultural Discovery Expedition",
    duration: "3 Days / 2 Nights",
    overview: "An intimate escape exploring Sri Lanka's deepest historical roots, beginning directly in the sacred ancient capital of Anuradhapura before summiting the fortress of Sigiriya.",
    days: [
      {
        day: 1,
        title: "Bandaranaike Airport to Sacred Anuradhapura Capital",
        start: "Colombo / Katunayake Airport",
        stop: "Anuradhapura Sacred Heritage City (First Stop)",
        route: "Airport -> Kurunegala -> Anuradhapura",
        driveTime: "Approx. 3.5 Hours in Private AC Vehicle",
        overnight: "Luxury Heritage Hotel, Anuradhapura",
        activities: [
          "VIP meet & greet inside airport arrivals hall by your private chauffeur guide",
          "Direct departure to the ancient sacred kingdom of Anuradhapura",
          "Afternoon reverence at the world-renowned Jaya Sri Maha Bodhi tree",
          "Marvel at the colossal white dome of Ruwanwelisaya stupa lit by evening butter lamps"
        ],
        tips: "Please wear white or light-colored attire with shoulders and knees covered for temple grounds."
      },
      {
        day: 2,
        title: "Mihintale Sacred Cradle & Sigiriya Countryside",
        start: "Anuradhapura",
        stop: "Mihintale & Sigiriya",
        route: "Anuradhapura -> Mihintale -> Habarana -> Sigiriya",
        driveTime: "Approx. 2 Hours",
        overnight: "Eco-Luxe Forest Chalet, Sigiriya",
        activities: [
          "Morning exploration of Jetavanarama (once third tallest brick structure in antiquity)",
          "Visit Mihintale rock monastery, where Buddhism was introduced to Sri Lanka in 247 BC",
          "Scenic transit to Sigiriya through emerald reservoir country",
          "Relaxation amidst peaceful forest sanctuary with traditional herbal refreshment"
        ],
        tips: "Climb Mihintale steps in the morning breeze for stunning 360-degree vistas."
      },
      {
        day: 3,
        title: "Sigiriya Lion Rock Fortress Ascent & Return",
        start: "Sigiriya",
        stop: "Sigiriya Sky Citadel -> Colombo Airport",
        route: "Sigiriya -> Kurunegala -> Colombo Airport",
        driveTime: "Approx. 4 Hours to Airport",
        overnight: "Departure Flight or Colombo Extension",
        activities: [
          "07:00 AM private guided ascent of Sigiriya Lion Rock Fortress",
          "Admire the ancient 5th-century cave frescoes and mirror wall inscriptions",
          "Panoramic views over the ancient royal gardens and jungle horizon",
          "Leisurely transit back to Colombo or direct drop-off at Bandaranaike Airport"
        ],
        tips: "Early start avoids midday sun on the iron stairs. Wear comfortable walking shoes."
      }
    ]
  },
  5: {
    title: "5-Day Cultural Highlights of Sri Lanka",
    duration: "5 Days / 4 Nights",
    overview: "The quintessential golden circuit connecting Anuradhapura, Sigiriya fortress, Dambulla cave temples, and the hill capital of Kandy.",
    days: [
      {
        day: 1,
        title: "Airport Welcome & Transit to Ancient Anuradhapura",
        start: "Bandaranaike International Airport",
        stop: "Sacred City of Anuradhapura (First Stop)",
        route: "Airport -> Anuradhapura",
        driveTime: "3.5 Hours",
        overnight: "Heritage Resort, Anuradhapura",
        activities: [
          "Personalized chauffeur welcome with cold scented towels and fresh king coconuts",
          "Private express drive north to ancient Anuradhapura",
          "Evening worship ceremony at the sacred Jaya Sri Maha Bodhi and Ruwanwelisaya",
          "Traditional Sri Lankan dinner at your heritage retreat"
        ],
        tips: "Rest well after your flight before the morning's archaeological walk."
      },
      {
        day: 2,
        title: "Anuradhapura Wonders & Mihintale Sanctuaries",
        start: "Anuradhapura",
        stop: "Anuradhapura Archaeological Park & Mihintale",
        route: "Anuradhapura Inner City -> Mihintale",
        driveTime: "Local excursions (Under 1 hour)",
        overnight: "Heritage Resort, Anuradhapura",
        activities: [
          "Witness the serene Samadhi Buddha statue sculpted in ancient granite",
          "Explore the monastic bathing twin ponds (Kuttam Pokuna)",
          "Ascent of Mihintale sanctuary mountain at golden hour",
          "Meditation opportunity overlooking surrounding dry-zone canopies"
        ],
        tips: "Slip-on footwear is convenient as shoes must be removed at Buddhist complexes."
      },
      {
        day: 3,
        title: "Sigiriya Lion Rock Citadel & Village Life",
        start: "Anuradhapura",
        stop: "Sigiriya & Habarana",
        route: "Anuradhapura -> Sigiriya",
        driveTime: "1.5 Hours",
        overnight: "Boutique Lagoon Resort, Sigiriya",
        activities: [
          "Morning climb of the iconic Sigiriya 5th-century rock fortress",
          "Authentic rural catamaran boat ride and mud-hut cooking demonstration",
          "Afternoon elephant viewing along nearby sanctuary borders",
          "Evening Ayurvedic head and shoulder massage"
        ],
        tips: "Carry water and sun hats for the Sigiriya rock walk."
      },
      {
        day: 4,
        title: "Dambulla Golden Cave Temples & Kingdom of Kandy",
        start: "Sigiriya",
        stop: "Dambulla Caves & Royal Kandy",
        route: "Sigiriya -> Dambulla -> Matale -> Kandy",
        driveTime: "2.5 Hours",
        overnight: "Hillside Luxury Hotel, Kandy",
        activities: [
          "Ascend Dambulla's UNESCO cave monastery with over 150 gold-lacquered Buddhas",
          "Visit an organic Matale spice garden with botanical specialist",
          "Scenic arrival into the misty amphitheater of Kandy",
          "Attend the vibrant evening Pooja ceremony at the Temple of the Sacred Tooth Relic"
        ],
        tips: "Kandy evenings are pleasantly cool; bring a light cardigan."
      },
      {
        day: 5,
        title: "Peradeniya Royal Botanical Gardens & Airport Drop-off",
        start: "Kandy",
        stop: "Peradeniya -> Colombo Airport",
        route: "Kandy -> Peradeniya -> Kadawatha Highway -> Airport",
        driveTime: "3 Hours",
        overnight: "Departure Flight",
        activities: [
          "Stroll beneath the towering Royal Palm avenues and giant Javan fig tree at Peradeniya",
          "View the renowned National Orchid House with over 400 species",
          "Scenic expressway journey to Colombo Airport in time for departure check-in"
        ],
        tips: "Chauffeur assists with VAT refunds and luggage check-in."
      }
    ]
  },
  7: {
    title: "7-Day Cultural & Hill Country Tour",
    duration: "7 Days / 6 Nights",
    overview: "Our flagship traveler journey: Starting at ancient Anuradhapura, climbing Sigiriya, experiencing royal Kandy, riding the mountain train through tea peaks to Ella, and concluding along the Dutch ramparts of Galle.",
    days: [
      {
        day: 1,
        title: "Airport Greeting to Sacred Capital of Anuradhapura",
        start: "Bandaranaike Airport, Katunayake",
        stop: "Anuradhapura Sacred Precincts (Stop #1)",
        route: "Airport -> Puttalam -> Anuradhapura",
        driveTime: "3.5 Hours",
        overnight: "Heritage Sanctuary, Anuradhapura",
        activities: [
          "Private chauffeur escort directly upon landing",
          "Scenic transit to UNESCO Anuradhapura",
          "Sunset lotus flower offering at Jaya Sri Maha Bodhi and Ruwanwelisaya Stupa",
          "Quiet welcome dinner in a courtyard illuminated by oil torches"
        ],
        tips: "Relax in air-conditioned comfort with complimentary bottled water and Wi-Fi."
      },
      {
        day: 2,
        title: "Anuradhapura Monastic Sites & Sigiriya Rock Citadel",
        start: "Anuradhapura",
        stop: "Sigiriya",
        route: "Anuradhapura -> Habarana -> Sigiriya",
        driveTime: "1.5 Hours",
        overnight: "Garden Chalet, Sigiriya",
        activities: [
          "Early stroll around Jetavanarama stupa & moonstone carvings",
          "Scenic drive toward Sigiriya rock fortress",
          "Late afternoon climb of Sigiriya Rock Fortress during optimal photography light",
          "Watch sunset over the central jungle plains from the summit ruins"
        ],
        tips: "Wear sturdy shoes for the summit ascent."
      },
      {
        day: 3,
        title: "Dambulla Painted Caves to Hill Capital of Kandy",
        start: "Sigiriya",
        stop: "Dambulla & Kandy",
        route: "Sigiriya -> Dambulla -> Kandy",
        driveTime: "2.5 Hours",
        overnight: "Heritage Mountain Retreat, Kandy",
        activities: [
          "Explore the 5 sacred cave sanctuaries of Dambulla perched high upon rock ridge",
          "Drive past spice terraces and highland foothills",
          "Evening visit to Sri Dalada Maligawa (Temple of the Tooth Relic) during musical Pooja",
          "Stroll around the tranquil colonial Kandy Lake"
        ],
        tips: "Cameras permitted outside shrine rooms; respectful silence maintained."
      },
      {
        day: 4,
        title: "Kandy to Nuwara Eliya 'Little England' & Tea Country",
        start: "Kandy",
        stop: "Nuwara Eliya (1,868m Altitude)",
        route: "Kandy -> Ramboda Falls -> Nuwara Eliya",
        driveTime: "2.5 Hours scenic mountain climb",
        overnight: "Colonial Tea Estate Bungalow, Nuwara Eliya",
        activities: [
          "Drive through cascading tea terraces and stop at twin Ramboda Falls",
          "Private walking tour through a functioning colonial tea processing factory",
          "Artisan Ceylon tea tasting session with certified tea master",
          "Colonial high tea on the manicured lawns overlooking Lake Gregory"
        ],
        tips: "Temperatures drop to 12-16°C in the evenings; warm layers recommended."
      },
      {
        day: 5,
        title: "Scenic Highland Blue Train to Ella & Nine Arch Bridge",
        start: "Nuwara Eliya (Nanu Oya Station)",
        stop: "Ella Mountain Hamlet",
        route: "Nanu Oya -> Ella by Scenic Train (Luggage transferred by car)",
        driveTime: "2.5 Hours scenic train journey",
        overnight: "Panoramic Mountain Villa, Ella",
        activities: [
          "Board the world-famous blue observation train traversing cloud forests and gorges",
          "Chauffeur meets you with your luggage at Ella station",
          "Afternoon hike to the architectural marvel of Nine Arch Demodara Bridge",
          "Watch the vintage locomotive cross the lush forest viaduct"
        ],
        tips: "Pre-reserved first or second class seats guarantee optimal window views."
      },
      {
        day: 6,
        title: "Ella to Galle Colonial Dutch Fort & South Coast",
        start: "Ella",
        stop: "Galle Dutch Fort",
        route: "Ella -> Rawana Waterfall -> Wellawaya -> Galle",
        driveTime: "3.5 Hours via Southern Expressway",
        overnight: "Luxury Merchant Villa inside Galle Fort",
        activities: [
          "Photo stop at the thundering Rawana Falls tumbling from mountain crests",
          "Descent through coconut plains to the southern Indian Ocean shoreline",
          "Late afternoon private walking tour across Galle Fort ramparts and lighthouse",
          "Gourmet seafood dinner inside the historic cobbled quarters"
        ],
        tips: "Galle Fort is completely pedestrian-friendly with delightful boutiques."
      },
      {
        day: 7,
        title: "Mirissa Beach Relaxation & Return Airport Transfer",
        start: "Galle",
        stop: "Mirissa Beach / Colombo Airport",
        route: "Galle -> Southern Expressway -> Airport",
        driveTime: "2 Hours to Airport",
        overnight: "Departure Flight",
        activities: [
          "Morning stroll along the golden sands of Mirissa or Galle Fort bastions",
          "Optional turtle sanctuary visit or stilt fishermen photography",
          "Comfortable expressway transfer directly to departures terminal"
        ],
        tips: "We arrive 3 hours prior to international flights for seamless check-in."
      }
    ]
  },
  10: {
    title: "10-Day Heritage, Nature & Safari Expedition",
    duration: "10 Days / 9 Nights",
    overview: "Comprehensive loop blending Sri Lanka's ancient kingdom capitals (Anuradhapura & Polonnaruwa), the misted tea peaks, exhilarating Yala leopard safari, and southern coast beaches.",
    days: [
      { day: 1, title: "Airport Greeting & First Stop at Sacred Anuradhapura", start: "Airport", stop: "Anuradhapura (Stop #1)", route: "Airport -> Anuradhapura", driveTime: "3.5 hrs", overnight: "Heritage Retreat, Anuradhapura", activities: ["VIP Airport Welcome", "Direct transfer to sacred capital", "Evening at Sri Maha Bodhi & Ruwanwelisaya stupa"], tips: "The most serene way to decompress after international flights." },
      { day: 2, title: "Anuradhapura Monastic Ruins & Mihintale Rock", start: "Anuradhapura", stop: "Anuradhapura & Mihintale", route: "Local precinct", driveTime: "1 hr", overnight: "Heritage Retreat, Anuradhapura", activities: ["Jetavanarama stupa discovery", "Kuttam Pokuna twin ponds", "Golden hour sunset climb at Mihintale"], tips: "Enjoy quiet morning reflection at monastic sites." },
      { day: 3, title: "Polonnaruwa Medieval Citadel Sculptures", start: "Anuradhapura", stop: "Polonnaruwa & Sigiriya", route: "Anuradhapura -> Polonnaruwa -> Sigiriya", driveTime: "2 hrs", overnight: "Forest Chalet, Sigiriya", activities: ["Explore Gal Vihara colossal rock-cut Buddha statues in Polonnaruwa", "Ancient royal palace ruins", "Catamaran lake cruise at dusk"], tips: "Gal Vihara represents the pinnacle of Sinhalese granite sculpture." },
      { day: 4, title: "Sigiriya Lion Fortress & Minneriya Elephant Gathering", start: "Sigiriya", stop: "Sigiriya & Minneriya", route: "Local loop", driveTime: "45 mins", overnight: "Forest Chalet, Sigiriya", activities: ["Early sunrise climb of Sigiriya Lion Rock", "Afternoon private 4x4 safari watching wild elephants congregate at Minneriya reservoir"], tips: "Observe elephant families safely from open safari jeeps." },
      { day: 5, title: "Dambulla Caves & The Temple of the Sacred Tooth", start: "Sigiriya", stop: "Dambulla & Kandy", route: "Sigiriya -> Dambulla -> Kandy", driveTime: "2.5 hrs", overnight: "Lakeside Hotel, Kandy", activities: ["UNESCO Dambulla golden cave temples", "Matale spice walk", "Temple of the Tooth Relic evening pooja"], tips: "Listen to the ceremonial temple drums during evening prayer." },
      { day: 6, title: "Highlands Tea Country & Colonial Nuwara Eliya", start: "Kandy", stop: "Nuwara Eliya", route: "Kandy -> Nuwara Eliya", driveTime: "2.5 hrs", overnight: "Tea Estate Bungalow, Nuwara Eliya", activities: ["Ramboda waterfall viewpoint", "Private tea tasting with tea masters", "Colonial heritage architecture stroll"], tips: "Enjoy cozy fireplace evenings in the hill country." },
      { day: 7, title: "Scenic Highland Train to Ella & Mountain Hikes", start: "Nuwara Eliya", stop: "Ella", route: "Nanu Oya -> Ella (Scenic Train)", driveTime: "2.5 hrs train", overnight: "Mountain View Chalet, Ella", activities: ["World-famous scenic train across tea plantations", "Hike Little Adam's Peak", "Nine Arch Bridge photography"], tips: "Chauffeur handles all luggage transfers seamlessly." },
      { day: 8, title: "Ella to Yala National Park & Leopard Safari", start: "Ella", stop: "Yala National Park", route: "Ella -> Rawana Falls -> Yala", driveTime: "2.5 hrs", overnight: "Safari Glamping Lodge, Yala", activities: ["Rawana Falls descent", "Check-in to luxury tented safari lodge", "Afternoon leopard & sloth bear tracking in private 4x4"], tips: "Keep telephoto camera lenses ready for wildlife action." },
      { day: 9, title: "Southern Coastline, Mirissa & Galle Dutch Fort", start: "Yala", stop: "Mirissa & Galle", route: "Yala -> Tangalle -> Mirissa -> Galle", driveTime: "2.5 hrs", overnight: "Boutique Fort Villa, Galle", activities: ["Scenic coastal drive past coconut bays", "Mirissa coconut tree hill visit", "Sunset ramparts walk in Galle Dutch Fort"], tips: "Sample fresh yellowfin tuna and lobster in Galle Fort." },
      { day: 10, title: "Mirissa Ocean Breezes to Colombo Airport", start: "Galle", stop: "Airport Departure", route: "Galle -> Southern Expressway -> Airport", driveTime: "2 hrs", overnight: "Departure Flight", activities: ["Morning coffee on historic ramparts", "Comfortable direct expressway transfer to Colombo Airport"], tips: "Chauffeur assists with check-in at departure terminal." }
    ]
  },
  15: {
    title: "15-Day Sri Lanka Discovery Grand Tour",
    duration: "15 Days / 14 Nights",
    overview: "An expansive grand voyage touching ancient kingdoms, the pristine east coast sands of Trincomalee, highlands, wildlife parks, and southern shores.",
    days: [
      { day: 1, title: "Airport Arrival to Sacred Capital Anuradhapura", start: "Airport", stop: "Anuradhapura (Stop #1)", route: "Airport -> Anuradhapura", driveTime: "3.5 hrs", overnight: "Heritage Retreat, Anuradhapura", activities: ["VIP welcome", "Direct transfer to ancient royal capital", "Jaya Sri Maha Bodhi sunset blessing"], tips: "Inaugural stop honoring ancient Ceylon heritage." },
      { day: 2, title: "Anuradhapura Sacred Archeological Wonder", start: "Anuradhapura", stop: "Anuradhapura", route: "Ancient city", driveTime: "Local", overnight: "Heritage Retreat, Anuradhapura", activities: ["Ruwanwelisaya and Jetavanarama stupas", "Abhayagiri monastery & Samadhi Buddha", "Kuttam Pokuna"], tips: "Learn the engineering secrets of ancient brick marvels." },
      { day: 3, title: "Mihintale to Eastern Shores of Trincomalee", start: "Anuradhapura", stop: "Trincomalee", route: "Anuradhapura -> Mihintale -> Trincomalee", driveTime: "2 hrs", overnight: "Beachfront Villa, Nilaveli Trincomalee", activities: ["Mihintale cradle of Buddhism", "Transit to white sand east coast", "Koneswaram Temple on Swami Rock cliff edge"], tips: "Koneswaram overlooks breathtaking drop into the Indian Ocean." },
      { day: 4, title: "Pigeon Island Marine Sanctuary & Beach Leisure", start: "Trincomalee", stop: "Nilaveli Beach", route: "Local boat", driveTime: "Local", overnight: "Beachfront Villa, Nilaveli", activities: ["Boat to Pigeon Island National Marine Park", "Snorkel with harmless blacktip reef sharks and sea turtles", "Afternoon coastal seafood barbecue"], tips: "Bring reef-safe sunscreen." },
      { day: 5, title: "Trincomalee to Sigiriya Cultural Triangle", start: "Trincomalee", stop: "Sigiriya", route: "Trincomalee -> Habarana -> Sigiriya", driveTime: "2 hrs", overnight: "Eco-Luxury Lodge, Sigiriya", activities: ["Scenic transit to the dry zone forest", "Pidurangala Rock sunset hike overlooking Sigiriya monolith"], tips: "Pidurangala offers the absolute best panoramic view of Sigiriya." },
      { day: 6, title: "Sigiriya Lion Rock & Polonnaruwa Ruins", start: "Sigiriya", stop: "Polonnaruwa", route: "Sigiriya -> Polonnaruwa -> Sigiriya", driveTime: "1.5 hrs", overnight: "Eco-Luxury Lodge, Sigiriya", activities: ["Sunrise climb of Sigiriya Lion Rock Fortress", "Bicycle or chauffeured tour of Polonnaruwa ancient palace ruins"], tips: "Marvel at King Parakramabahu's Council Chamber." },
      { day: 7, title: "Dambulla Caves to Royal Capital of Kandy", start: "Sigiriya", stop: "Kandy", route: "Sigiriya -> Dambulla -> Kandy", driveTime: "2.5 hrs", overnight: "Lakeside Heritage Suite, Kandy", activities: ["Dambulla Cave temples", "Matale spice grove", "Temple of the Sacred Tooth Relic evening ceremonies"], tips: "Observe the historic cultural rituals preserved over centuries." },
      { day: 8, title: "Peradeniya Botanical Majesty & Kandy Artisans", start: "Kandy", stop: "Kandy", route: "Local city", driveTime: "Local", overnight: "Lakeside Heritage Suite, Kandy", activities: ["Royal Botanical Gardens of Peradeniya", "Visit traditional Kandyan batiks and woodcarvers", "Traditional dance performance"], tips: "Take in the serene beauty of the giant orchid collection." },
      { day: 9, title: "Highlands Tea Country & Colonial Nuwara Eliya", start: "Kandy", stop: "Nuwara Eliya", route: "Kandy -> Nuwara Eliya", driveTime: "2.5 hrs", overnight: "Colonial Manor, Nuwara Eliya", activities: ["Ramboda Falls scenic climb", "Colonial tea factory private tour & tasting", "High tea at historic Grand Hotel"], tips: "Experience true colonial hospitality and cool highland mist." },
      { day: 10, title: "Scenic Highland Train to Ella", start: "Nuwara Eliya", stop: "Ella", route: "Nanu Oya -> Ella (Scenic Train)", driveTime: "2.5 hrs train", overnight: "Boutique Mountain Chalet, Ella", activities: ["First-class scenic train through mountain tunnels", "Little Adam's Peak gentle climb", "Nine Arch Bridge photography"], tips: "Luggage transferred seamlessly by your private driver." },
      { day: 11, title: "Ella to Yala National Park", start: "Ella", stop: "Yala", route: "Ella -> Wellawaya -> Yala", driveTime: "2.5 hrs", overnight: "Wild Safari Glamping, Yala", activities: ["Rawana Falls descent", "Evening private game drive in Yala tracking leopards and elephants"], tips: "Yala features the highest concentration of leopards on earth." },
      { day: 12, title: "Udawalawe Elephant Sanctuary Safari", start: "Yala", stop: "Udawalawe / Tangalle", route: "Yala -> Udawalawe -> Tangalle", driveTime: "2 hrs", overnight: "Oceanfront Resort, Tangalle", activities: ["Morning elephant tracking in open savannas of Udawalawe", "Afternoon arrival at serene southern coast beaches"], tips: "Udawalawe guarantees magnificent elephant encounters in natural habitats." },
      { day: 13, title: "Tangalle to Galle Dutch Fort", start: "Tangalle", stop: "Galle Fort", route: "Tangalle -> Mirissa -> Galle", driveTime: "1.5 hrs", overnight: "Historic Fort Manor, Galle", activities: ["Mirissa coconut hill stop", "Wander Galle Fort cobbled lanes and 17th-century ramparts", "Private architectural walking tour"], tips: "Enjoy boutique shopping for Ceylon gems and artisan spices." },
      { day: 14, title: "Galle Fort Leisure & Maritime Heritage", start: "Galle", stop: "Galle & Bentota", route: "Coastal drive", driveTime: "1 hr", overnight: "Beach Luxury Resort, Bentota", activities: ["Morning swim in calm southern bays", "Visit Kosgoda Turtle Conservation Center", "Madu River boat safari through mangrove tunnels"], tips: "Hold baby sea turtles undergoing conservation care." },
      { day: 15, title: "Bentota to Colombo City & Airport Departure", start: "Bentota", stop: "Airport Departure", route: "Bentota -> Colombo -> Airport", driveTime: "1.5 hrs expressway", overnight: "Departure Flight", activities: ["Brief orientation tour of historic Colombo (Independence Square & Old Dutch Hospital)", "Transfer to departures terminal"], tips: "Depart with memories of a royal island traverse." }
    ]
  },
  20: {
    title: "20-Day Complete Island Odyssey",
    duration: "20 Days / 19 Nights",
    overview: "A comprehensive expedition including the far-northern Jaffna peninsula, sacred Anuradhapura heritage, eastern white sands, central highlands, deep south wildlife, and historic Galle.",
    days: [
      { day: 1, title: "VIP Arrival & First Destination Anchor: Anuradhapura", start: "Airport", stop: "Anuradhapura (Stop #1)", route: "Airport -> Anuradhapura", driveTime: "3.5 hrs", overnight: "Heritage Resort, Anuradhapura", activities: ["Private airport reception", "Immediate journey to ancient capital", "Sunset homage at Jaya Sri Maha Bodhi"], tips: "The golden starting anchor for this all-island odyssey." },
      { day: 2, title: "Anuradhapura Antiquities & Mihintale Ascent", start: "Anuradhapura", stop: "Anuradhapura & Mihintale", route: "Local precinct", driveTime: "Local", overnight: "Heritage Resort, Anuradhapura", activities: ["Ruwanwelisaya and Jetavanarama stupas", "Kuttam Pokuna twin ponds", "Mihintale golden hour ascent"], tips: "Immerse in ancient hydraulic and monastic marvels." },
      { day: 3, title: "Journey North to the Jaffna Peninsula", start: "Anuradhapura", stop: "Jaffna", route: "Anuradhapura -> Vavuniya -> Elephant Pass -> Jaffna", driveTime: "3.5 hrs", overnight: "Boutique Heritage Hotel, Jaffna", activities: ["Crossing historic Elephant Pass into the northern peninsula", "Afternoon visit to the colossal Nallur Kandaswamy Hindu temple", "Savor authentic Jaffna crab curry dinner"], tips: "A distinct, vibrant Tamil cultural experience with ornate kovils." },
      { day: 4, title: "Jaffna Fort, Casuarina Beach & Nagadeepa Island", start: "Jaffna", stop: "Jaffna Islands", route: "Jaffna -> Kurikadduwan Jetty -> Ferry", driveTime: "Local", overnight: "Boutique Heritage Hotel, Jaffna", activities: ["Boat ride to sacred Nagadeepa Purana Viharaya island", "Casuarina Beach white sands stroll", "Jaffna Dutch Fort sunset walk"], tips: "Feel the untouched serenity of Sri Lanka's northern frontier." },
      { day: 5, title: "Jaffna to the Coral Bays of Trincomalee", start: "Jaffna", stop: "Trincomalee", route: "Jaffna -> Mullaitivu -> Trincomalee", driveTime: "4 hrs", overnight: "Beachfront Resort, Nilaveli Trincomalee", activities: ["Scenic transit through north-eastern coastlines", "Koneswaram Temple cliffside homage", "Nilaveli beach relaxation"], tips: "Trincomalee boasts one of the world's deepest natural harbors." },
      { day: 6, title: "Pigeon Island Marine Reserve & Snorkeling", start: "Trincomalee", stop: "Nilaveli", route: "Boat trip", driveTime: "Local", overnight: "Beachfront Resort, Nilaveli", activities: ["Private boat to Pigeon Island", "Snorkeling with reef sharks and sea turtles", "Fresh coconut water on the beach"], tips: "Unmatched underwater visibility during summer months." },
      { day: 7, title: "Trincomalee into the Cultural Triangle", start: "Trincomalee", stop: "Sigiriya", route: "Trincomalee -> Habarana -> Sigiriya", driveTime: "2 hrs", overnight: "Forest Chalet, Sigiriya", activities: ["Transit to lush interior forest realm", "Catamaran lake ride and rural village cooking feast", "Pidurangala Rock sunset hike"], tips: "Pidurangala offers a dramatic silhouette of Sigiriya." },
      { day: 8, title: "Sigiriya Lion Rock & Polonnaruwa Sculptures", start: "Sigiriya", stop: "Polonnaruwa", route: "Sigiriya -> Polonnaruwa -> Sigiriya", driveTime: "1.5 hrs", overnight: "Forest Chalet, Sigiriya", activities: ["Sunrise climb of Sigiriya Lion Rock citadel", "Gal Vihara colossal granite Buddhas in Polonnaruwa"], tips: "King Parakramabahu's grand capital comes alive with our historian guide." },
      { day: 9, title: "Minneriya Wild Elephant Gathering Safari", start: "Sigiriya", stop: "Minneriya / Kaudulla", route: "Local sanctuary", driveTime: "Local", overnight: "Forest Chalet, Sigiriya", activities: ["Leisurely morning at your resort pool", "Afternoon open-top 4x4 safari watching wild elephants assemble"], tips: "Witness hundreds of elephants interact along the water's edge." },
      { day: 10, title: "Dambulla Caves & Royal Kingdom of Kandy", start: "Sigiriya", stop: "Kandy", route: "Sigiriya -> Dambulla -> Kandy", driveTime: "2.5 hrs", overnight: "Hillside Luxury Hotel, Kandy", activities: ["Dambulla Cave temples", "Matale spice walk", "Temple of the Tooth Relic evening ceremonies"], tips: "Experience the sacred relic veneration ritual." },
      { day: 11, title: "Peradeniya Royal Gardens & Knuckles Foothills", start: "Kandy", stop: "Kandy & Foothills", route: "Local scenic drive", driveTime: "Local", overnight: "Hillside Luxury Hotel, Kandy", activities: ["Peradeniya Royal Botanical Gardens", "Scenic excursion to Knuckles mountain foothills", "Kandyan cultural dance performance"], tips: "Marvel at the giant Javan fig tree and bamboo groves." },
      { day: 12, title: "Misty Tea Plantations to Nuwara Eliya", start: "Kandy", stop: "Nuwara Eliya", route: "Kandy -> Nuwara Eliya", driveTime: "2.5 hrs", overnight: "Heritage Tea Manor, Nuwara Eliya", activities: ["Ramboda Falls", "Colonial tea processing walk and master cupping", "High tea at the Grand Hotel"], tips: "Pack warm evening clothes for highland elevations." },
      { day: 13, title: "Horton Plains & World's End Precipice", start: "Nuwara Eliya", stop: "Horton Plains", route: "Nuwara Eliya -> Horton Plains -> Nuwara Eliya", driveTime: "1 hr each way", overnight: "Heritage Tea Manor, Nuwara Eliya", activities: ["Dawn nature walk to World's End 870m sheer cliff drop", "Baker's Falls cascade", "Spotting endemic highland sambar deer"], tips: "Start at dawn before morning clouds blanket the cliff face." },
      { day: 14, title: "Scenic Highland Blue Train to Ella", start: "Nuwara Eliya", stop: "Ella", route: "Train to Ella", driveTime: "2.5 hrs train", overnight: "Boutique Villa, Ella", activities: ["Classic scenic train journey through tea estates", "Nine Arch Bridge viaduct walk", "Little Adam's Peak sunset"], tips: "Your driver handles all luggage safely by road." },
      { day: 15, title: "Ella to Yala National Park", start: "Ella", stop: "Yala", route: "Ella -> Rawana Falls -> Yala", driveTime: "2.5 hrs", overnight: "Luxury Safari Camp, Yala", activities: ["Rawana Falls descent", "Check-in to luxury tented safari camp", "Evening leopard and sloth bear tracking"], tips: "Sleep surrounded by ambient night sounds of the wild." },
      { day: 16, title: "Udawalawe National Park Elephant Safari", start: "Yala", stop: "Udawalawe", route: "Yala -> Udawalawe", driveTime: "1.5 hrs", overnight: "Riverside Safari Resort, Udawalawe", activities: ["Full-day wildlife experience", "Visit Elephant Transit Home rehabilitation center", "Safari in open grasslands"], tips: "See orphaned baby elephants being nourished and returned to the wild." },
      { day: 17, title: "Udawalawe to Mirissa & South Coast Beaches", start: "Udawalawe", stop: "Mirissa", route: "Udawalawe -> Mirissa", driveTime: "2 hrs", overnight: "Beachfront Boutique Resort, Mirissa", activities: ["Transit to the golden south coast", "Afternoon ocean swim", "Fresh grilled seafood on the sand"], tips: "Savor the tranquil coastal rhythm of the Indian Ocean." },
      { day: 18, title: "Mirissa Whale Watching & Galle Fort Ramparts", start: "Mirissa", stop: "Galle Fort", route: "Mirissa -> Weligama -> Galle", driveTime: "1 hr", overnight: "Colonial Fort Villa, Galle", activities: ["Dawn marine cruise spotting blue whales", "Stilt fishermen photography at Weligama", "Sunset walk across Galle Fort 17th-century ramparts"], tips: "Witness the largest creatures on earth just off the coast." },
      { day: 19, title: "Galle Fort Living Heritage & Ayurvedic Spa", start: "Galle", stop: "Galle Fort", route: "Walking tour", driveTime: "None", overnight: "Colonial Fort Villa, Galle", activities: ["Guided architectural walk through Dutch colonial monuments", "Gems and jewelry boutique visits", "Comprehensive 2-hour full body Ayurvedic wellness therapy"], tips: "The perfect restorative finish to an extensive journey." },
      { day: 20, title: "Galle to Colombo & Airport Departure", start: "Galle", stop: "Airport Departure", route: "Galle -> Southern Expressway -> Airport", driveTime: "2 hrs", overnight: "Departure Flight", activities: ["Leisurely breakfast on the veranda", "Expressway transfer to Colombo Airport", "Departure farewell with your dedicated chauffeur guide"], tips: "Travel Zoom concierge stays with you until airport security entrance." }
    ]
  },
  30: {
    title: "30-Day Royal Ceylon Immersion & Wellness",
    duration: "30 Days / 29 Nights",
    overview: "The definitive slow-travel sovereign immersion. Starts with 3 full days anchored in sacred Anuradhapura before traversing Wilpattu jungle, Jaffna, Trincomalee, the Cultural Triangle, high tea estates, deep wildlife parks, and an extended southern Ayurvedic wellness residency.",
    days: [
      { day: 1, title: "VIP Arrival & First Destination Anchor: Anuradhapura", start: "Airport", stop: "Anuradhapura (Stop #1)", route: "Airport -> Anuradhapura", driveTime: "3.5 hrs", overnight: "Private Heritage Estate, Anuradhapura", activities: ["VIP arrivals reception", "Direct private transfer to ancient capital", "Initial blessing at sacred Jaya Sri Maha Bodhi"], tips: "The golden anchor of this slow-travel journey." },
      { day: 2, title: "Anuradhapura Sacred Stupas & Monastic Gardens", start: "Anuradhapura", stop: "Anuradhapura", route: "Ancient city", driveTime: "Local", overnight: "Private Heritage Estate, Anuradhapura", activities: ["Ruwanwelisaya and Jetavanarama stupas", "Abhayagiri monastery & Samadhi Buddha", "Kuttam Pokuna"], tips: "Leisurely exploration with our senior archaeologist guide." },
      { day: 3, title: "Mihintale Sacred Cradle & Forest Hermitages", start: "Anuradhapura", stop: "Mihintale & Ritigala", route: "Anuradhapura -> Ritigala", driveTime: "1 hr", overnight: "Private Heritage Estate, Anuradhapura", activities: ["Mihintale monastery ascent", "Ritigala strict nature reserve and ancient Ayurvedic hospital ruins", "Evening meditation under Bodhi tree"], tips: "Ritigala remains one of Sri Lanka's most mystical monastic ruins." },
      { day: 4, title: "Wilpattu National Park Private Safari Expedition", start: "Anuradhapura", stop: "Wilpattu", route: "Anuradhapura -> Wilpattu", driveTime: "1 hr", overnight: "Wild Safari Camp, Wilpattu", activities: ["Full day safari across Wilpattu's natural sand-rimmed lakes (Villus)", "Tracking leopards, sloth bears, and barking deer"], tips: "Sri Lanka's largest and oldest national park, uncrowded and wild." },
      { day: 5, title: "Wilpattu Wilderness to Northern Mannar Island", start: "Wilpattu", stop: "Mannar", route: "Wilpattu -> Mannar", driveTime: "2.5 hrs", overnight: "Boutique Coastal Lodge, Mannar", activities: ["Scenic transit past ancient baobab trees planted by Arab sailors", "View Adam's Bridge sandbanks stretching toward India", "Flamingo flock observation"], tips: "Mannar is an exotic landscape rich in migratory birdlife." },
      { day: 6, title: "Mannar to the Jaffna Peninsula", start: "Mannar", stop: "Jaffna", route: "Mannar -> Elephant Pass -> Jaffna", driveTime: "3 hrs", overnight: "Heritage Hotel, Jaffna", activities: ["Journey into northern Jaffna", "Evening Pooja at Nallur Kandaswamy temple", "Sample traditional Jaffna cuisine"], tips: "Immerse in unique Tamil culture, architecture, and cuisine." },
      { day: 7, title: "Jaffna Fort, Keerimalai Springs & Point Pedro", start: "Jaffna", stop: "Jaffna Peninsula", route: "Local loop", driveTime: "Local", overnight: "Heritage Hotel, Jaffna", activities: ["Historic Jaffna Dutch Fort", "Healing mineral waters of Keerimalai seaside springs", "Point Pedro northernmost tip of Sri Lanka"], tips: "Taste sweet palmyrah fruit delicacies." },
      { day: 8, title: "Delft Island Wild Pony Expedition", start: "Jaffna", stop: "Delft Island", route: "Ferry from Kurikadduwan Jetty", driveTime: "Ferry cruise", overnight: "Heritage Hotel, Jaffna", activities: ["Ferry to secluded Delft Island made of coral rock", "View wild horses left by Dutch and Portuguese colonizers", "Growing rock and giant baobab tree"], tips: "A truly surreal island stepping stone trapped in time." },
      { day: 9, title: "Jaffna to Eastern White Beaches of Nilaveli", start: "Jaffna", stop: "Nilaveli, Trincomalee", route: "Jaffna -> Trincomalee", driveTime: "4 hrs", overnight: "Beach Luxury Resort, Nilaveli", activities: ["Scenic journey down eastern coastline", "Arrival at tranquil white sand beach resort", "Sunset cocktails overlooking the bay"], tips: "East coast beaches are at their calmest and most crystalline." },
      { day: 10, title: "Pigeon Island Coral Snorkeling & Koneswaram", start: "Trincomalee", stop: "Pigeon Island", route: "Local boat", driveTime: "Local", overnight: "Beach Luxury Resort, Nilaveli", activities: ["Private marine safari at Pigeon Island", "Snorkel among coral gardens with reef sharks and turtles", "Clifftop visit to historic Koneswaram Temple"], tips: "The azure water is extraordinarily clear." },
      { day: 11, title: "Leisure Beach Residency in Nilaveli", start: "Trincomalee", stop: "Nilaveli Beach", route: "None", driveTime: "0 hrs", overnight: "Beach Luxury Resort, Nilaveli", activities: ["Uninterrupted day of coastal relaxation", "Beachfront massage and fresh tropical dining"], tips: "Embrace the true unhurried tempo of slow travel." },
      { day: 12, title: "Nilaveli to Sigiriya Cultural Triangle", start: "Trincomalee", stop: "Sigiriya", route: "Trincomalee -> Sigiriya", driveTime: "2 hrs", overnight: "Eco-Luxury Lodge, Sigiriya", activities: ["Transit to interior forest sanctuary", "Pidurangala Rock sunset hike"], tips: "Marvel at Sigiriya rock monolith glowing in sunset ember." },
      { day: 13, title: "Sigiriya Lion Rock & Polonnaruwa Ancient City", start: "Sigiriya", stop: "Polonnaruwa", route: "Sigiriya -> Polonnaruwa -> Sigiriya", driveTime: "1.5 hrs", overnight: "Eco-Luxury Lodge, Sigiriya", activities: ["Dawn ascent of Sigiriya Lion Rock Fortress", "Afternoon bicycle tour through Polonnaruwa royal palace grounds and Gal Vihara"], tips: "Beat the midday sun by starting at sunrise." },
      { day: 14, title: "Minneriya Wild Elephant Gathering", start: "Sigiriya", stop: "Minneriya", route: "Local reserve", driveTime: "45 mins", overnight: "Eco-Luxury Lodge, Sigiriya", activities: ["Traditional rural village cooking feast", "Private open-top 4x4 safari watching wild elephants assemble"], tips: "A magnificent conservation success story." },
      { day: 15, title: "Dambulla Caves & Spice Terraces to Kandy", start: "Sigiriya", stop: "Kandy", route: "Sigiriya -> Dambulla -> Kandy", driveTime: "2.5 hrs", overnight: "Heritage Manor, Kandy", activities: ["Dambulla Cave temples", "Organic spice exploration in Matale", "Evening Temple of the Tooth Relic ceremony"], tips: "Hear the rhythmic drumming of evening prayer." },
      { day: 16, title: "Kandy Royal Botanical Gardens & Artisan Guilds", start: "Kandy", stop: "Kandy", route: "Local", driveTime: "Local", overnight: "Heritage Manor, Kandy", activities: ["Peradeniya Royal Botanical Gardens", "Visit traditional silversmiths and gem lapidaries", "Kandyan dance recital"], tips: "Exquisite hand-carved heritage crafts." },
      { day: 17, title: "Misty Tea Valleys to Colonial Nuwara Eliya", start: "Kandy", stop: "Nuwara Eliya", route: "Kandy -> Nuwara Eliya", driveTime: "2.5 hrs", overnight: "Historic Tea Estate Bungalow, Nuwara Eliya", activities: ["Scenic ascent past Ramboda Falls", "Colonial tea factory private tour & tea master cupping", "High tea at Grand Hotel"], tips: "Pure mountain crisp air at 1,800m." },
      { day: 18, title: "Horton Plains & World's End Sunrise", start: "Nuwara Eliya", stop: "Horton Plains", route: "Local mountain drive", driveTime: "1 hr each way", overnight: "Historic Tea Estate Bungalow, Nuwara Eliya", activities: ["Sunrise trek across cloud forest plateau to World's End", "Baker's Falls cascade", "Afternoon golf or leisure by Lake Gregory"], tips: "Bring a warm fleece for the early start." },
      { day: 19, title: "World-Famous Mountain Blue Train to Ella", start: "Nuwara Eliya", stop: "Ella", route: "Scenic train to Ella", driveTime: "2.5 hrs train", overnight: "Panoramic Chalet, Ella", activities: ["Board the scenic blue mountain train through tea hills", "Nine Arch Bridge photography", "Little Adam's Peak sunset"], tips: "Driver transfers luggage ahead to your hotel." },
      { day: 20, title: "Ella Gap Hiking & Waterfalls", start: "Ella", stop: "Ella", route: "Local trails", driveTime: "Local", overnight: "Panoramic Chalet, Ella", activities: ["Morning hike up Ella Rock", "Swim at secret mountain pools above Diyaluma Falls"], tips: "Sensational views extending all the way to the southern coastline." },
      { day: 21, title: "Ella to Yala National Park Leopard Safari", start: "Ella", stop: "Yala", route: "Ella -> Rawana Falls -> Yala", driveTime: "2.5 hrs", overnight: "Wild Safari Glamping, Yala", activities: ["Rawana Falls descent", "Evening private game drive tracking leopards and sloth bears in Yala"], tips: "Spot the magnificent Sri Lankan leopard in its natural scrub jungle." },
      { day: 22, title: "Full-Day Deep Wilderness Safari in Yala", start: "Yala", stop: "Yala Block 1 & 2", route: "National Park", driveTime: "Safari Jeep", overnight: "Wild Safari Glamping, Yala", activities: ["Dawn-to-dusk safari with packed bush breakfast and lunch by the river", "Elephant herds, crocodiles, and endemic birdlife"], tips: "The most in-depth wildlife exploration possible." },
      { day: 23, title: "Udawalawe Elephant Sanctuary", start: "Yala", stop: "Udawalawe", route: "Yala -> Udawalawe", driveTime: "1.5 hrs", overnight: "Riverside Resort, Udawalawe", activities: ["Visit Elephant Transit Home rehabilitation center", "Safari in open savannas of Udawalawe"], tips: "Heartwarming insight into elephant orphan conservation." },
      { day: 24, title: "Arrival at Southern Coast Ayurveda Sanctuary", start: "Udawalawe", stop: "Tangalle & Dikwella", route: "Udawalawe -> South Coast", driveTime: "2 hrs", overnight: "Ayurveda Wellness Sanctuary, Southern Coast", activities: ["Check-in to premier Ayurvedic beachfront sanctuary", "Initial comprehensive consultation with Ayurvedic physician to determine dosha type", "Evening herbal steam therapy"], tips: "Beginning of 5-day restorative body and mind rebalancing." },
      { day: 25, title: "Ayurvedic Treatments & Yoga by the Ocean", start: "South Coast", stop: "Sanctuary", route: "None", driveTime: "0 hrs", overnight: "Ayurveda Wellness Sanctuary, Southern Coast", activities: ["Sunrise yoga and pranayama meditation", "Synchronized Abhyanga herbal oil massages", "Customized dosha-specific nutrition"], tips: "Feel years of travel fatigue gently melt away." },
      { day: 26, title: "Shirodhara & Herbal Baths", start: "South Coast", stop: "Sanctuary", route: "None", driveTime: "0 hrs", overnight: "Ayurveda Wellness Sanctuary, Southern Coast", activities: ["Shirodhara warm oil therapy for profound nervous system calm", "Herbal flower bath", "Sunset coastal walk"], tips: "Shirodhara is famous for inducing profound mental clarity and sound sleep." },
      { day: 27, title: "Mirissa Blue Whale Safari & Coastal Wonders", start: "South Coast", stop: "Mirissa", route: "Coastline", driveTime: "30 mins", overnight: "Ayurveda Wellness Sanctuary, Southern Coast", activities: ["Dawn marine cruise spotting blue whales in the deep Indian ocean", "Coconut Tree Hill visit", "Restorative evening treatment"], tips: "Witness the majestic blue whale breach the ocean surface." },
      { day: 28, title: "Galle Dutch Fort Living Heritage Manor", start: "South Coast", stop: "Galle Dutch Fort", route: "South Coast -> Galle", driveTime: "1 hr", overnight: "Colonial Luxury Merchant Manor, Galle Fort", activities: ["Scenic transfer to historic Galle Fort", "Private walking tour across ramparts, lighthouse, and Dutch Reformed Church", "Gourmet coastal seafood dinner"], tips: "A vibrant UNESCO fort where history meets contemporary boutique life." },
      { day: 29, title: "Galle Fort Boutiques & Farewell Dinner", start: "Galle", stop: "Galle Fort", route: "Walking tour", driveTime: "0 hrs", overnight: "Colonial Luxury Merchant Manor, Galle Fort", activities: ["Leisurely stroll through artisan jewelry ateliers and spice boutiques", "Sunset cocktail on the western bastions", "Celebratory farewell banquet with your private guide team"], tips: "Collect world-famous Ceylon blue sapphires and artisan cinnamon." },
      { day: 30, title: "Galle to Colombo Airport Departure", start: "Galle", stop: "Colombo Airport Departure", route: "Galle -> Southern Expressway -> Airport", driveTime: "2 hrs expressway", overnight: "Departure Flight", activities: ["Breakfast on the colonial veranda", "Comfortable direct expressway transfer to Bandaranaike Airport", "Farewell assistance at departure hall"], tips: "A sovereign journey concluded with lifelong memories of Ceylon." }
    ]
  }
};

export const TOUR_PACKAGES: TourPackage[] = [
  {
    id: 3,
    days: 3,
    nights: 2,
    title: "3-Day Cultural Discovery",
    category: "Cultural Triangle",
    durationGroup: "3-5",
    styles: ["Cultural & Heritage", "Private Tours", "Solo Explorers"],
    routeStops: ["Anuradhapura", "Mihintale", "Sigiriya Lion Rock"],
    description: "Immerse yourself directly in Ceylon's earliest chronicle. Pay homage at the sacred Jaya Sri Maha Bodhi before ascending the cradle of Buddhism and Sigiriya's sky fortress.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC3U2E5OlPz9vSkPCCyhNz4nZHQw99gfoXMZ64s5NGteijxHuz8dt8gnz4D-3uKPF3eUbj6M9AByXsjeDklZoI2A3O6mtLBiOU8wWhkj1phhf9hErJ6dr0C9Lbm_j8djR4ZWiv9HdpkDTjnOHrTeFXnTvZPz5HsQ_rjji68Mh_TVJbZnKzDlUQOyzTkp-pLu3QpTUy-A9ut5JiJjmE1f45lj9FgKt7Lp-7m3TSX70JNWPT5qQ1bOow1",
    imageAlt: "The ancient colossal Ruwanwelisaya stupa in sacred Anuradhapura Sri Lanka gleaming bright white under dramatic twilight sky with Buddhist prayer flags and oil lamps.",
    priceNote: "Bespoke Quote"
  },
  {
    id: 5,
    days: 5,
    nights: 4,
    title: "5-Day Cultural Highlights",
    category: "Heritage Classic",
    durationGroup: "3-5",
    styles: ["Cultural & Heritage", "Senior-Friendly Comfort", "Private Tours"],
    routeStops: ["Anuradhapura", "Mihintale", "Sigiriya", "Dambulla", "Kandy"],
    description: "Experience Sri Lanka's golden quadrangle starting at the first Sinhalese capital, traversing Dambulla's painted caves, into the sacred hill capital of Kandy.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD7BNS2puwc0AEMUyd_FLfHRlxx2_UzL-P2Q69kLqATwhksMec9Cvbg_7xWP4moL3Ndu0rgAzeDYhpyjor1-yh7ERxImAyQ9i0phb18B33UjAQILeP55YB2KaP3l9MH-4d8saJTLvlSVVbzHauM9xVklSTsrygO8dIkAW7nQE6NIOgjPoo6XAZeVosg0G-5MlaET3oRv-ANkJ8BlqeHMlbhbk0F-md51bqS09IFW7A7GkRAOC2yKAKa",
    imageAlt: "Sigiriya fortress rock viewed through water gardens and reflecting pools at sunset in Sri Lanka, majestic golden hour light reflecting in still water.",
    priceNote: "Custom Quotation"
  },
  {
    id: 7,
    days: 7,
    nights: 6,
    title: "7-Day Cultural & Hill Country",
    category: "Cultural & Highlands",
    tag: "Most Popular",
    durationGroup: "7-10",
    styles: ["Couples & Honeymoon", "Family Expeditions", "Private Tours"],
    routeStops: ["Anuradhapura", "Sigiriya", "Kandy", "Nuwara Eliya", "Ella", "Galle"],
    description: "The essential Sri Lankan tapestry. Anuradhapura ruins, mist-cloaked tea estates, colonial architecture, and the Dutch Fort of Galle with private chauffeur freedom.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDkbvzuXvOZfxwS2T9GDxILlpO5eyBogDk4Gtb2cImqGYy7ZUEfXP-BSwbsJ1noVoYL_6n6SDOjTAxTZEHiRsm-wF-3F4XlmtLMWCPw6-T87w4pKQXoWuI3NbV9mRLaSzYuacN_PdUfgZtZljOiHZUwJD-ddMN-3CnAityq4UrJsdEzv0SqDgx64xesEatGBpFc1RR75yeNtgvALHSsuOaPwZF1pbp1K7dKjW_MIXPDGGWl7G1NX_aW",
    imageAlt: "Scenic blue train crossing the Nine Arch Bridge in Ella Sri Lanka surrounded by lush green tea plantations and rolling morning hills.",
    priceNote: "Tailor-Made Quote"
  },
  {
    id: 10,
    days: 10,
    nights: 9,
    title: "10-Day Heritage, Nature & Safari",
    category: "Wildlife & Coast",
    durationGroup: "7-10",
    styles: ["Wildlife & Safari", "Family Expeditions", "Private Tours"],
    routeStops: ["Anuradhapura", "Polonnaruwa", "Sigiriya", "Kandy", "Ella", "Yala Safari", "Mirissa"],
    description: "From ancient Anuradhapura stupas and Polonnaruwa carvings into central tea peaks, thrilling leopard tracking in Yala, and south coast ocean serenity.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuA6NF88kbsd3tw81zwexhLHuZoQxKVmBXHJkW3PFsrFQJGjs8a_eWWfAQZPQ_wgXZKrpIyQymED73sCrSUEC5-qZ33iE5fQWx1KxpPO6QJz0MPoY9YZIE3UwLMReSmSaFn1aK6Wz88OFMoImqV_Ys7aK11VYXDRWyJl5N0mO0omKo8-aSVgoA_NMC2JloxjFRctkxh56cTVRXNwxLwWWYesCO7V8DzU4uwx9ImaoqLBzsH7APesMCU8",
    imageAlt: "Majestic wild Sri Lankan leopard resting upon a massive granite boulder in Yala National Park during golden afternoon light with wilderness acacia trees.",
    priceNote: "Tailor-Made Quote"
  },
  {
    id: 15,
    days: 15,
    nights: 14,
    title: "15-Day Discovery Grand Tour",
    category: "Grand Odyssey",
    durationGroup: "15-20",
    styles: ["Bespoke Holidays", "Cultural & Heritage", "Couples & Honeymoon"],
    routeStops: ["Anuradhapura", "Trincomalee", "Sigiriya", "Kandy", "Nuwara Eliya", "Yala", "Galle", "Colombo"],
    description: "Uncompromising island circuit featuring East Coast white beaches of Trincomalee, highlands, wildlife safaris, and Dutch maritime fortifications.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDRW_j2xUIz-deQxmOnvcWXdFoCfHt-aczreUnQvigjRTe3umNB71typsSvj3LwMDFW__4cwerS5dUgXCjgq5Ydfpgm9bwZfjv9Wdqpx6P4AR9Ad_iK4-XKuoVkWQiiF94FhsV0kyNkQgvOqzLlBOWmT38RSyKfk8-xLULT5ZDtuLdCPrZU6uodweeXgr-CojlSvcmGdUR4cZCYwx7w1sdAvXTiEocoe0uOadKdJVcXJgkhU3Ciijr0",
    imageAlt: "Private luxury colonial tea estate bungalow in Nuwara Eliya Sri Lanka overlooking mist rolling across vibrant manicured tea hills under soft evening light.",
    priceNote: "Tailor-Made Quote"
  },
  {
    id: 20,
    days: 20,
    nights: 19,
    title: "20-Day Complete Island Odyssey",
    category: "All-Island Expedition",
    durationGroup: "15-20",
    styles: ["Solo Explorers", "Bespoke Holidays", "Cultural & Heritage"],
    routeStops: ["Anuradhapura", "Jaffna", "Trincomalee", "Cultural Triangle", "Highlands", "Yala & Deep South"],
    description: "Venture past the conventional circuits. Northern Jaffna peninsula, sacred Anuradhapura heritage, eastern seas, central tea estates, and wild southern coastlines.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuB8MuonBgd0VfCb5ZHiOT1fdgtgHQ8gKt_dCDjad7PamkeyUFPvF2clw8dKgWBwRhUPMPx2QqmkfuwZ2WXH-hWvu4jSlPUVa-IUgLFj3BiMMmCewcz6x6Ml1uudUJVxtZ-TkOOAaWYzqYQ_NGgMzNckQJKbKUhFtrF7F7Vmp_92ADlr7ibbzsZQhPS33Y7GxTb-C-WxiR1ncisFNIVOLS1uojWVeCcPx9-U7cqfCHUm1bNNTsPK22uk",
    imageAlt: "Ancient Nallur Kandaswamy Kovil Hindu temple in Jaffna Sri Lanka glowing with golden dusk illumination and ornate carved gateway towers.",
    priceNote: "Tailor-Made Quote"
  },
  {
    id: 30,
    days: 30,
    nights: 29,
    title: "30-Day Royal Ceylon Immersion & Wellness",
    category: "Sovereign Slow Travel",
    tag: "Masterpiece",
    durationGroup: "30",
    styles: ["Senior-Friendly Comfort", "Bespoke Holidays", "Solo Explorers", "Couples & Honeymoon"],
    routeStops: ["Anuradhapura (3D)", "Wilpattu (2D)", "Jaffna (3D)", "Trincomalee & Passikudah (5D)", "Cultural Triangle (4D)", "Kandy & Highlands (5D)", "Yala (2D)", "Southern Coast Sanctuary & Ayurveda (6D)"],
    description: "The quintessential slow-travel masterpiece. Spend meaningful multiday residencies in ancient monasteries, secluded wilderness lodges, and premier coastal Ayurveda sanctuaries with your dedicated senior chauffeur naturalist.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAJr_FC_PxD0MW7hp5IpLN5L6GiITCH7HyKp-6wLsrRWF8a3w6o_B3clt7NYEMyEDYP7DFZqPF6rTPmG7EyGK6IFWRq1T7StHjp7pvTux9sNeMcdQgs2cC-nQcdvNc-zWuNpA7-fgyOdUqQkF0EmFlN07gQGHuT1fPWH5g0mFyhsR3frqHTOzF_qyREXu5eIPUkt6lK6to2L2-RUtUw2xW3Mi1njl8FsbTDb8eVtRIyRz3LUTIRsruu",
    imageAlt: "Serene Ayurveda luxury retreat nestled in lush tropical rainforest in Sri Lanka with tranquil lily pond and warm wooden architecture in warm evening light.",
    priceNote: "VIP Private Quotation"
  }
];

export const TRAVELER_PERSONAS: TravelerPersona[] = [
  {
    id: "private-tours",
    number: "01",
    title: "Private Chauffeur Tours",
    icon: "directions_car",
    description: "Exclusive air-conditioned vehicle, vetted local English chauffeur guide, complete itinerary flexibility.",
    filterStyle: "Private Tours"
  },
  {
    id: "couples-honeymoon",
    number: "02",
    title: "Couples & Honeymoon",
    icon: "favorite",
    description: "Secluded tea estate chalets, candlelit beach dinners in Mirissa, and romantic heritage suite stays.",
    filterStyle: "Couples & Honeymoon"
  },
  {
    id: "family-expeditions",
    number: "03",
    title: "Family Expeditions",
    icon: "family_restroom",
    description: "Spacious private vans, multi-room boutique villas, gentle safari adventures, and kid-friendly cultural workshops.",
    filterStyle: "Family Expeditions"
  },
  {
    id: "cultural-heritage",
    number: "04",
    title: "Cultural & Heritage",
    icon: "temple_buddhist",
    description: "Deep dives into Anuradhapura stupas, Polonnaruwa ruins, Sigiriya frescoes, and Kandy temple rituals.",
    filterStyle: "Cultural & Heritage"
  },
  {
    id: "wildlife-safari",
    number: "05",
    title: "Wildlife & Safari",
    icon: "pets",
    description: "Expert-guided jeep safaris in Yala, Minneriya, and Wilpattu targeting leopards, elephants, and sloth bears.",
    filterStyle: "Wildlife & Safari"
  },
  {
    id: "solo-explorers",
    number: "06",
    title: "Solo Explorers",
    icon: "person_pin_circle",
    description: "Safe, empowering independent journeys with 24/7 dedicated local concierge and vetted private chauffeurs.",
    filterStyle: "Solo Explorers"
  },
  {
    id: "senior-comfort",
    number: "07",
    title: "Senior-Friendly Comfort",
    icon: "chair",
    description: "Relaxed driving schedules, step-free luxury lodging options, luggage assistance, and unhurried temple visits.",
    filterStyle: "Senior-Friendly Comfort"
  },
  {
    id: "bespoke-holidays",
    number: "08",
    title: "Bespoke Luxury",
    icon: "diamond",
    description: "Helicopter scenic transfers, private Ceylon tea bungalow buyouts, wellness retreats, and culinary masters.",
    filterStyle: "Bespoke Holidays"
  }
];

export const FLEET_VEHICLES: FleetVehicle[] = [
  {
    id: "sedan",
    title: "Executive Luxury Sedan",
    capacity: "1-3 Passengers",
    model: "Toyota Premio / Allion or luxury hybrid",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBG7tKKG-BRNWZPc_aicsifLI87TJlgQvPf0IlQRHM7vNRR-3o5zNoCOriXp_n7AaSn2wH52NcRLwycp-Wl-THx7N29zybMBsLED2j9o5kAcbk8btg5RmyYA3AfapBQL_FFEBKoZ1Joh56Hze53UiHPP6WPXufjVzPhTu7YORzFGoejxTUji7OnbjYKeSn97NMA2AJF30XJ_UfUWcJ5Agt-CJZPLWRAqr5ngmJq7BIoHQWJYZwgqSy-",
    imageAlt: "Chauffeur driven luxury modern sedan car parked near an ancient Buddhist stupa in Sri Lanka in pristine clean condition.",
    description: "Toyota Premio / Allion or luxury hybrid. Ideal for couples, solo travelers, and executive duos.",
    features: [
      "Dual-zone Climate Control",
      "2 Large + 2 Hand Luggage",
      "Complimentary High-Speed Onboard Wi-Fi"
    ]
  },
  {
    id: "minivan",
    title: "Luxury Family Mini Van",
    capacity: "4-7 Passengers",
    model: "Toyota KDH High-Roof / Super GL",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAmf9fd_azvI_fuYtho5tbZ-SXLyHvAY-isGrc_6Jk3A8vXRSoJNtCpuleof8ZN3VWG7iStN5hgf5e11zUxIXQL-EaiROgKf89boYo4PeyWrQt9SxRfyCQh1IxlUWQWCdWKrJ-u6xNTl24Dk7lIucatKXBkfzBBWUs7oiI7D8VrTQL9o5Q6UMMYAJndzqgB5ayNpTcumencP5uO4bZXvsgMo3rDr4lOjimL9cw3FCRyTlc7FL6jaN4C",
    imageAlt: "Spacious luxury private tourist minivan parked on scenic mountain roadway in the tea country of Nuwara Eliya Sri Lanka.",
    description: "Toyota KDH High-Roof / Super GL with reclining captain seats and panoramic sightlines.",
    features: [
      "Individual Overhead AC Vents",
      "5-7 Suitcases + Daypacks",
      "Multi-port USB phone chargers"
    ]
  },
  {
    id: "minibus",
    title: "Luxury Commuter Mini Bus",
    capacity: "8-14 Passengers",
    model: "Toyota Coaster or executive mini-coach",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBQwxLxODYiaqNAon0GJ0KxsF9xyu6Tyu3ON54nGq0dW_3BiDssdA9brIGF_zcWWVqJCtDxsHIQg5C2BPkEclqMBzxpkslmmPaK8Pu5cnPztDs4_i1B4yT6rU44j6CmHsys-sy6T1eMvbPFsjt83S4-l1bM40eMZe7X2THZcx7CA-y26uQV6FsyXfslE4-an_RnOg0wjh0fExbgL_WrpDp7TFn45jfZoqTRxZzLhLmfnw24auxPSukH",
    imageAlt: "Executive mini coach tour bus touring scenic coastal highway in Galle Sri Lanka with spacious windows.",
    description: "Toyota Coaster or executive mini-coach. Built for group tours, extended family delegations, and corporate retreats.",
    features: [
      "Ergonomic reclining seats",
      "Dedicated rear luggage bay",
      "PA System & Guide Microphone"
    ]
  },
  {
    id: "suv-prado",
    title: "Private 4x4 SUV Prado",
    capacity: "1-4 Passengers",
    model: "Toyota Land Cruiser Prado 4WD",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAgZb5OrD7_a0BDhAi5PxiRZSlg96UeBFHWBEdUuSvVrVUaADPZXmQqUGtdrW6FT5z6ADDloNjEz9CwSrYgul5L8vIHDtqJ0rpY67dczqAUN8dHdeX12xv3nhzCJw4oFqoqMDCEBNfVk-2n67myHd8kNrnBICYdHN-1cFsk6SfiWdFj44WSfhplJWb0oP_yeZQki5dR5d7vfpCa9DajcDGzn58l-l64Hul-Hf9M4WnYOix93m30iO8y",
    imageAlt: "Rugged luxury 4x4 SUV vehicle parked near a scenic wilderness reserve in Sri Lanka with jungle foliage.",
    description: "Toyota Land Cruiser Prado 4WD. Enhanced high clearance for off-road mountain passes and rugged safari approaches.",
    features: [
      "High-clearance AWD",
      "3 Large Suitcases",
      "Premier Safety Package"
    ]
  }
];

export const CURATED_ACTIVITIES: CuratedActivity[] = [
  {
    id: "act-1",
    title: "Anuradhapura Sacred Stupas Exploration",
    badge: "Inaugural Experience",
    badgeColor: "bg-primary text-on-primary",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCBVj2ppTYit1gENxe0zm7VvUuqGm1RV9VQaUyBWic0GvjM6WCgxrMY9TQQMnSoHNIa4bSi_5iq4ByomBLksFxPjssUA9QoXvvFZWylxvNJwH5RzDIgbr4_5W-YAUa3Wuhy20HOJtYS5qncG8fgsdrK0Ng1xeW6fTBsxRXbJ7RFZ4Sw-NRhHlwnTsw7qp5X2hzjOrBq45P0BkeIzD_wTZorR_BSljBMkp_osOPzPBdH30T2x0ZLy_Rk",
    imageAlt: "Sacred Sri Maha Bodhi tree in Anuradhapura with pilgrims in white clothes offering lotus flowers in soft golden morning sunlight.",
    description: "Guided reverence at the world's oldest historically documented tree (Jaya Sri Maha Bodhi) and the majestic dome of Ruwanwelisaya.",
    durationTag: "Included in all tours • 4-6 Hours"
  },
  {
    id: "act-2",
    title: "Sigiriya Lion Rock Fortress Climb",
    badge: "UNESCO Wonder",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAI2Zfz8eDRMImMMLVt2KZbSmB9DlrK8FAKVOYRTaVycvBcCT9EFeJyaCVeijgLtcLbcumsmsxJH7rgX2QWLgmW86BZwasPJJo7PYSZCLlVQbG80S2DZRrwejWGNVIMzIJPv9WJZSMh86mUIE79WC79NB8tNV6c4-QfTJ7IProkWs6hWY25SNGw_p2MZS5ANihK454DHJLQgWIDqeWdr5yAcdKozg6FHxd0x6Vi0oP4tuijieZpeUsB",
    imageAlt: "Ancient frescoes and Lion Rock paw stairway of Sigiriya Citadel in Sri Lanka with panoramic morning skies.",
    description: "Early morning sunrise ascent of King Kashyapa's 5th-century palace in the sky before the heat and crowds arrive.",
    durationTag: "Private Guide • 3 Hours"
  },
  {
    id: "act-3",
    title: "Minneriya Elephant Gathering Safari",
    badge: "Wildlife Spectacle",
    badgeColor: "bg-tertiary-container text-on-tertiary",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDfyKfZP0aVwKaNBGv511VlkAZks0c9nKpkLwAHJ5NB4BbOH06AzmE28yWdqxvZBnAKHbjjcm3h3Vc2reSk3Dd8DvdQDjHEqjBR2uALxVSxREFIHUch0D9lC94swicJJ954rY7NtWdPCMKNr7JIFNMP32D2tJGsERSbZGU35G3oYHqR_Q4FoJabjtLFGShVIDLXaVdtd3cURFpi0XzNz180mqwGg0ZH0c7gNZJPVVXDdyHnmRnRlyKC",
    imageAlt: "Large herd of wild Asian elephants gathered near the water edge at Minneriya National Park reservoir during golden hour in Sri Lanka.",
    description: "Witness hundreds of wild elephants socializing and grazing along the ancient reservoir shores in open-top 4x4 jeeps.",
    durationTag: "Private 4x4 Jeep • Afternoon"
  },
  {
    id: "act-4",
    title: "Kandy to Ella Mountain Train Ride",
    badge: "World Famous",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBhAOlxSqLXE7nTIigSMK3Vl0xZeMVLUhnfGHkfqScS5cH7RqHkZe6coAzOd6lw6Yr3Xk0UVttzcc--chnfxMJH4kVF1lkeb86do-7tFYd_jAApZ1PpCm92Ylc52LYWcUIQ-kGoKol4_Bw8pYg0CEit7B5fqFQSpI4GBbdHSZ9tMxUMK4Wc6mNOWguQZEuV3lPQifUSeOgWLdQuxXN_OSmhPnI3y9fvP3FdvNIgUfm7fc-xX7YtVweV",
    imageAlt: "Classic scenic highland train journey between Kandy and Ella curving through lush emerald tea estates with passengers looking out wide windows.",
    description: "Reserved first or second-class observation seats. Your private chauffeur transfers luggage ahead to your Ella hotel.",
    durationTag: "Reserved Tickets • 3-4 Hours"
  },
  {
    id: "act-5",
    title: "Ceylon Tea Tasting & Estate Walk",
    badge: "Sensory Heritage",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCjL1yGsiPTeKv1FdX6zQadUUlHQZ5dysDf0pMjXnAoyZt22-Fp7KIPIm-FZlDQXkRzNmKCVaSFOHo9w30r1krQ9jc-H-QumJmvEp-XLIfs1P-KVP9HYpQF2zOeZLRHCF0mk6o1hutVyeXwSeQeHCjEo3nnys_oNfczy6m4GdfzrJNjecx91toq7TFu30T8R43ItYQaY5DAoVhLe-ZOHPvg5ZZlDpAX9Q9JrI6h3MTb412qVmz-POg8",
    imageAlt: "Traditional tea plucker woman in colorful saree harvesting fresh Ceylon tea leaves in misty highlands of Nuwara Eliya with factory in background.",
    description: "Private guided tour through historic colonial tea factories, master cupping sessions, and walks through high-grown plantations.",
    durationTag: "Tea Master Escort • 2.5 Hours"
  },
  {
    id: "act-6",
    title: "Sigiriya Village Cooking Experience",
    badge: "Authentic Taste",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBWN1VbER60ldtHgLWCAxJUcy3Tj0UcI4l7nW71tFIDy6dPq4zSSGnQmP0r2sO9JijarE8VyMoRkBmHWV3SAThEbynCZkFZQ_0jsBFL9oZlLSrYuA5ZxXwq7VWgEGhRm1V7ezyWT47CMmcr585S-5ANl3zhU0yfTYv_XxKYvxTQ3gV00XDW_3TnioZrZ1ezBP9DPi1wt-XAN7miirmfMowApukW8NgesVy0QQ7TbQAl4Jlct5zNa7KT",
    imageAlt: "Traditional Sri Lankan clay pot curry cooking over open wood fire in a rural village setting with fresh spices and coconut milk.",
    description: "Catamaran ride across a lotus lake followed by an authentic culinary masterclass in a traditional rural mud-walled dwelling.",
    durationTag: "Lunch Included • 3 Hours"
  },
  {
    id: "act-7",
    title: "Yala National Park Leopard Safari",
    badge: "Apex Predator",
    badgeColor: "bg-tertiary-container text-on-tertiary",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuA4O-JrStH16lD0BRm-X6MWldlEIwtyALe3HzlPYTS5ylO5-K-Doo0CuAKeBfw2w3-X6ZfrB2CUAwKS1hxW6IP64wdlw1rNDS-xRz_cXddrH1yOEDtXDLE46Xla0OJABP_DL0kEhzZNQwqzj0NDrBm-wWfxaRQQGxQhp5IKURlD3YJM_Zk1CVZF3ejjyAhaJ0eBv0YhBYB4w2asthJ1HVETEGT4QqeCGEpVxg6ZyYhM7x4A_49Liou8",
    imageAlt: "Yala National Park rugged savanna landscape with safari jeep observing wildlife near a freshwater waterhole at sunrise.",
    description: "Early dawn private safari tracking the highest density of leopards in the world, alongside sloth bears and crocodiles.",
    durationTag: "Custom 4x4 Jeep • Dawn / Dusk"
  },
  {
    id: "act-8",
    title: "Mirissa Blue Whale Watching",
    badge: "Ocean Marine Life",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuABBkQej8WNZ6d9UoBBPJFZvcQ8-ozmYppubBs-4sKE2uZNvfSXi3xEXOSCyfEm99Sn6-XfPF4TsQPetGxLQJGQKXkeaPX3crHAQY7banzZytCaUNJ1WSlqzFjzDDs1XfSA8cDEu88QFJH4lURApCeCRKzi-dXfF9n79WIEOvPM9spLqzmgv-GoYNaumVbz32RP1v6yRxi07Er9wEuh6NBUIC3JD4jeInBX3f0QNBUX-K37G4S3tkuP",
    imageAlt: "Spectacular blue whale tail fluke rising out of deep ocean water off the southern coast of Mirissa Sri Lanka during early morning cruise.",
    description: "Ethical, coastguard-certified ocean expedition to spot blue whales, sperm whales, and spinning dolphins in the warm Indian Ocean.",
    durationTag: "Boat Cruise • 4-5 Hours"
  },
  {
    id: "act-9",
    title: "Authentic Ayurveda & Shirodhara",
    badge: "Holistic Wellness",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBmN4-S1JgwT48XNBDIBP6oYx7dmcvRAfnL3PBjQuKJzZPtqpRsNKJuNvBDYjKNnxlVaXQFz8POIL0y8ua-Ft8N4tGcaf4HqHk0UyvfNUooTm_2E6rWAA3DqCd6vqOFtd9YYrSrD6siJ4s7OppzOBCtu_IaZf0CuiE7gni0ZVOzCAN2NkcRHe7iDYXnTbvOjAkEKai6wSrcYkZ9RGLpU_EWC7bw34BPtZPbIi0qG6Nvxy34pE7wjbEu",
    imageAlt: "Tranquil traditional Ayurvedic oil massage treatment room with warm wooden decor herbal flowers and incense in Sri Lanka sanctuary.",
    description: "Consultation with certified Ayurvedic doctors, therapeutic warm herbal oil treatments, and calming meditation sessions.",
    durationTag: "Certified Doctors • 2-4 Hours"
  }
];

export const DESTINATION_REGIONS: DestinationRegion[] = [
  {
    id: "anuradhapura",
    title: "Anuradhapura: The Sacred Ancient Capital",
    region: "North Central Province",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuATHsGzbcypD0WMIElFHStofrkYWAdydwS0vIesc7u5LNQD6YtFgVxEa5Si3fMyHv62shPM_GrQdeY_lpDiBBXkqT8CYctuDrdE1TmzmXapcP2VJlFsbPDxgOuT8Tc52k6PXxLPvLZQfPRzXKq_lEH0WUVKAwap-JzCxXoW6gogr-Wp7fJ8tTj_lpXG6BlR-6FSJgiNj1bsTDagzXhyFU_JbUm7GU7KwlZRBxI4ZIDCyCXRuXBNi5k4",
    imageAlt: "Majestic panoramic view of ancient Anuradhapura Sri Lanka with multiple ancient stupas rising above vast greenery under evening sun.",
    description: "Sri Lanka's earliest recorded royal capital for over a millennium. Revered pilgrimage site preserving the sacred Bodhi tree, giant brick stupas (Ruwanwelisaya, Jetavanarama), and serene stone monastic ponds.",
    meta: "Drive: 3.5 hrs from Colombo • Best Season: Year-Round",
    isHeroAnchor: true
  },
  {
    id: "sigiriya-dambulla",
    title: "Sigiriya & Dambulla",
    region: "Cultural Triangle",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAXRvPsoTfcrOaPfH0NCedvgDGjgonhPft19hCtzrpesrBLVoIZXMilcz-FRnSFVbo44xfMvFHQVVRwFTs26Bo-H1yXoozMlYVzR0cstMbiouiAW5rfzv7bGkI-6yCj1uPrH7QKonxXg2YSXmagNtccubxR6TQR959mlowmZ1mKuw-y_f94NPVU1mu9-hDYuslNng7qHrElMfe5at_bW2k3J6yxsb4B_IHtCDOuQBiRwZJYLZRRGPWM",
    imageAlt: "Dambulla cave temple golden Buddha statues illuminated warmly inside ancient rock cavern in Sri Lanka.",
    description: "The 5th-century rock citadel, ancient water engineering marvels, and Dambulla's sacred cave murals.",
    meta: "Central Plains"
  },
  {
    id: "kandy",
    title: "Kandy Sacred Realm",
    region: "Hill Capital",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDNWxHH6lOtsENT0dfXZaqI8vdvJyeQWl6MglrpME3OUNgiGBNf5hR3uOzb2AfJIDsXDRi4T5PRGHCjTitXBh1hVybct6SMkAicIX4zabJYgGIsRc7Z1LhMeIKu_2J-fFQZfnj9T4LDpwBKKQ0ej7dlQyFitNZkLAIqLKK6e8hZlMIfiNOFxBY7J20CdBlw61-2LLpnnG-XiVayQ3CfXPiuP8hRZIPELhW5LD9n5LsawRzqimipoC0j",
    imageAlt: "Temple of the Sacred Tooth Relic across Kandy lake in Sri Lanka at dusk with glowing city reflections.",
    description: "Royal botanical gardens of Peradeniya, Sri Dalada Maligawa (Temple of the Tooth), and lakeside walks.",
    meta: "Central Foothills"
  },
  {
    id: "nuwara-eliya-ella",
    title: "Nuwara Eliya & Ella",
    region: "Highlands 1,800m",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAYg_XlV24uyys7FaogUHr4ZEN8w_zugebp354VlrTwtVwJlytcifoKSnoqhZawXD3lGvPAIQNWQ1X77hBRHtE6ufY7vDDHlrtNHC5KCAIzYyw3yMt8u6Xj2XDBWxTt9r2Y9EbVPWiPr6bt2kRy07KYyZ30mTaEHM89MSjGv_1X_zkujgSudWpxXqPpgdHjECoAZZYLweQuucr5pXbDdbqvjEYfKRV7KYOTbBO6rfBBQduNSHxzxIvn",
    imageAlt: "Vast rolling mountain vistas of Ella Gap Sri Lanka with waterfalls and tea hills during dramatic sunrise.",
    description: "Cool mountain air, misty pine forests, Little Adam's Peak, and colonial Ceylon tea estates.",
    meta: "Central Massif"
  },
  {
    id: "galle-mirissa",
    title: "Galle & Mirissa",
    region: "Southern Coast",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDtMsPKW1KWR-fXoqXPKCp1KABXBBDNW35dK3GoZtys9uaUQLcItINrfAKoQ5tz4yZus_YZQ1acDHerDdV-3oO1CAVk4ATqwLHzlSU0LUuGjb6XuOEkVfJiVEma7iDDnoTg9-OdQzYsWwAkFRICz87WyKmAEiJ6BUht48x6hPaYyjKxzbEebI0orIuDf1NELdeSW91_pI4Tu_KUnuuI4dtvyljnv1dMbUt36lU1uOnfVdYruY32ODkE",
    imageAlt: "Historic Galle Fort lighthouse in Sri Lanka standing proud over palm trees and the crashing turquoise Indian Ocean waves.",
    description: "17th-century Dutch ramparts, jewel boutiques, artisan coffee houses, whale watching, and golden beaches.",
    meta: "Indian Ocean Shoreline"
  }
];

export const REVIEWS_LIST: ReviewItem[] = [
  {
    id: "rev-1",
    name: "Mark & Angela Davies",
    locationAndTrip: "United Kingdom • 10-Day Private Tour",
    timeAgo: "2 months ago",
    rating: 5,
    comment: "“Starting our 10-day trip in Anuradhapura instead of rushing to Sigiriya was the best decision we made! Our driver-guide made us feel like royalty. Spotless luxury van, insightful Buddhist history, and zero stress.”",
    initials: "MA"
  },
  {
    id: "rev-2",
    name: "Lars & Karin Lindqvist",
    locationAndTrip: "Sweden • 15-Day Family Grand Tour",
    timeAgo: "3 weeks ago",
    rating: 5,
    comment: "“The level of honesty and attention to detail from Travel Zoom Tours is world-class. Our chauffeur never pushed tourist shops, always took us to sublime local food spots, and was so gentle with our young children.”",
    initials: "LK"
  },
  {
    id: "rev-3",
    name: "Elena Rossi",
    locationAndTrip: "Italy • 7-Day Solo Exploration",
    timeAgo: "1 month ago",
    rating: 5,
    comment: "“As a solo female traveler, safety and comfort were paramount. Travel Zoom delivered impeccably. From the Anuradhapura ruins to tea plantations and Mirissa, I felt completely protected and cherished.”",
    initials: "ER"
  }
];

export const FAQ_LIST: FaqItem[] = [
  {
    id: 1,
    question: "Why does every Travel Zoom itinerary start in Anuradhapura?",
    answer: "Anuradhapura is the spiritual and civilization cradle of Sri Lanka, standing uninterrupted for over 1,400 years. Starting your journey here provides profound historical context to the ruins, reservoirs, art, and Buddhism that you will encounter later in Sigiriya, Polonnaruwa, and Kandy. Located 3.5 hours directly north of Bandaranaike International Airport, it allows you to escape Colombo traffic immediately and awaken in serenity."
  },
  {
    id: 2,
    question: "Can we customize the days, hotels, or route completely?",
    answer: "Absolutely. 100% of our tours are private and tailor-made. The 3, 5, 7, 10, 15, 20, and 30-day itineraries displayed are tested blueprints. You can alter pacing, substitute hotels, add extra days in tea estates or south-coast surf beaches, or blend different elements to your liking."
  },
  {
    id: 3,
    question: "Are airport meet & greet and private airport transfers included?",
    answer: "Yes. Your dedicated chauffeur guide will be waiting right inside the arrivals hall holding a personalized Travel Zoom Tours name placard, assist with your luggage, provide a local high-speed SIM card if required, and escort you to your air-conditioned private vehicle."
  },
  {
    id: 4,
    question: "Are driver accommodation, food, and highway toll expenses included?",
    answer: "Yes! We operate with absolute line-item transparency. All chauffeur driver allowances, overnight hotel accommodation for the driver, meals, express expressway toll fees, fuel, and vehicle insurance are fully covered in our quotation. You never face awkward roadside charges."
  },
  {
    id: 5,
    question: "Do your drivers take travelers to aggressive souvenir shopping traps?",
    answer: "No. Travel Zoom Tours operates under a strict Zero-Commission Shopping Policy. You will never be redirected to overpriced gemstone factories, batik shops, or spice gardens unless you explicitly request to purchase something specific. Your time belongs purely to your holiday."
  },
  {
    id: 6,
    question: "How do payment schedules and currency options work?",
    answer: "Once you approve your custom itinerary, we confirm reservations with a modest deposit via secure international wire transfer, credit card link, or Wise. The remaining balance can be settled prior to arrival or comfortably upon meeting your chauffeur in Sri Lanka in USD, EUR, GBP, or LKR."
  },
  {
    id: 7,
    question: "What is your cancellation and flexibility policy?",
    answer: "We understand travel plans can shift. We offer flexible rescheduling up to 14 days before arrival without penalty fees, and transparent refunds based on individual hotel cancellation policies."
  },
  {
    id: 8,
    question: "Can you accommodate travelers with dietary requirements or reduced mobility?",
    answer: "Yes, our chauffeurs coordinate directly with luxury hotel chefs to guarantee strict Halal, Vegan, Gluten-Free, or Jain food preparations. For senior guests, we choose ground-floor suites, select accessible scenic viewpoints, and tailor walking paces."
  },
  {
    id: 9,
    question: "Is Sri Lanka currently safe and hospitable for international tourists?",
    answer: "Sri Lanka is extraordinarily safe, peaceful, and warm. Tourism is the lifeblood of our island, and locals welcome visitors with genuine hospitality. Having a dedicated private vehicle and trusted local guide eliminates all logistical stress."
  },
  {
    id: 10,
    question: "How early should we book our tour?",
    answer: "For peak season voyages (December to April and July to August), we recommend booking 2 to 4 months in advance to secure premier boutique tea bungalows and first-class scenic train tickets. However, our concierge handles last-minute bookings with 48 hours notice."
  }
];
